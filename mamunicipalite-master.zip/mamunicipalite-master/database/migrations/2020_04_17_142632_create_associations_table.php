<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAssociationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('associations', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('matricule');
            $table->string('autorisation_key');
            $table->string('domain');
            $table->string('address');
            $table->string('email');
            $table->string('bank');
            $table->string('bank_agency');
            $table->string('bank_rib');
            $table->string('tel');
            $table->string('fax');
            $table->date('creation_date');
            $table->boolean('published')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('associations');
    }
}
