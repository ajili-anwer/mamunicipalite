<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAssociationWorksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('association_works', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('association_id');
            $table->string("title");
            $table->longText("text");
            $table->longText("files");
            $table->enum("type", ['a', 'p']);
            $table->date('realization_date');
            $table->boolean('published')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('association_works');
    }
}
