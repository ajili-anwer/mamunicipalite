<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGovernoratsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('governorats', function (Blueprint $table) {
            $table->increments('id');
            $table->string('lib_gov_ar');
            $table->string('lib_gov_fr');
            $table->string('lib_gov_en');
            $table->string('code_gov');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('governorats');
    }
}
