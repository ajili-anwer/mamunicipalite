<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnActiveToDemandDomain extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('demand_domains', function (Blueprint $table) {
           $table->boolean("active")->default(1)->after("lib_en");
        });
        Schema::table('demand_themes', function (Blueprint $table) {
           $table->boolean("active")->default(1)->after("lib_en");
        });
       Schema::table('demand_sub_themes', function (Blueprint $table) {
           $table->boolean("active")->default(1)->after("lib_en");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('demand_domains', function (Blueprint $table) {
            $table->dropColumn("active");
        });
        Schema::table('demand_themes', function (Blueprint $table) {
            $table->dropColumn("active");
        });
        Schema::table('demand_sub_themes', function (Blueprint $table) {
            $table->dropColumn("active");
        });
    }
}
