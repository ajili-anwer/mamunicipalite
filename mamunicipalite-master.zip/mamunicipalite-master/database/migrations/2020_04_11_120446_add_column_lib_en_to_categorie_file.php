<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnLibEnToCategorieFile extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('categorie_file', function (Blueprint $table) {
            $table->string('libelle_en')->after("libelle_fr");
            //
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('categorie_file', function (Blueprint $table) {
            $table->dropColumn('libelle_en');

        });
    }
}
