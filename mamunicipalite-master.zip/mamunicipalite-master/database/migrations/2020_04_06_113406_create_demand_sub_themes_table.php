<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDemandSubThemesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('demand_sub_themes', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('demand_theme_id');
            $table->string('lib_ar');
            $table->string('lib_fr');
            $table->string('lib_en');
            $table->foreign('demand_theme_id',env('DB_TABLE_PREFIX').'demand_theme_id')->references('id')->on('demand_themes')->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('demand_sub_themes');
    }
}
