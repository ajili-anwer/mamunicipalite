<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnToAssociationMembres extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('association_membres', function (Blueprint $table) {
           $table->unsignedInteger("association_id")->after("function_id");
           $table->boolean("verified")->default(0)->after("association_id");

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('association_membres', function (Blueprint $table) {
            $table->dropColumn("association_id");
            $table->dropColumn("verified");
        });
    }
}
