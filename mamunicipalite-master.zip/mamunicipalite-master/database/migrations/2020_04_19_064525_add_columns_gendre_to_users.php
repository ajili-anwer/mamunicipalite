<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsGendreToUsers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
           $table->enum("gender",['m',"f"])->nullable();
           $table->enum("marital_status",['s',"m",'d',"w"])->nullable();
           $table->string("function")->nullable();
           $table->unsignedInteger("nationality")->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn("gender");
            $table->dropColumn("marital_status");
            $table->dropColumn("function");
            $table->dropColumn("nationality");
        });
    }
}
