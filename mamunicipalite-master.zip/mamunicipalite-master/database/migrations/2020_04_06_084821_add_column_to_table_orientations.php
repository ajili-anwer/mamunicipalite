<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnToTableOrientations extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orientations', function (Blueprint $table) {
            $table->string("orientation_en")->default("")->after("orientation_ar");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orientations', function (Blueprint $table) {
            $table->dropColumn("orientation_en");

        });
    }
}
