<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangeTypeOfDate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        \Illuminate\Support\Facades\DB::statement('ALTER TABLE '.env('DB_TABLE_PREFIX').'events MODIFY date_start TIMESTAMP ;');
        \Illuminate\Support\Facades\DB::statement('ALTER TABLE '.env('DB_TABLE_PREFIX').'events MODIFY date_end	TIMESTAMP ;');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
}
