<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDemandDomainsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('demand_domains', function (Blueprint $table) {
            $table->increments('id');
            $table->string('lib_ar');
            $table->string('lib_fr');
            $table->string('lib_en');
            $table->timestamps();
        });
        Schema::table('demand_themes', function (Blueprint $table) {
            $table->unsignedInteger('domain_id')->after("id");
            $table->foreign('domain_id',env('DB_TABLE_PREFIX').'demand_domain_id')->references('id')->on('demand_domains')->onDelete('cascade');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('demand_themes', function (Blueprint $table) {
            $table->dropColumn('domain_id');


        });
        Schema::dropIfExists('demand_domains');
    }
}
