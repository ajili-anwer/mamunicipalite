<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddComumnThemeTableDemand extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('demands', function (Blueprint $table) {
            $table->unsignedInteger('sub_theme_id')->after("user_id");

            $table->foreign('sub_theme_id',env('DB_TABLE_PREFIX').'sub_theme_id')->references('id')->on('demand_sub_themes')->onDelete('cascade');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('demands', function (Blueprint $table) {
            $table->dropColumn('sub_theme_id');

        });
    }
}
