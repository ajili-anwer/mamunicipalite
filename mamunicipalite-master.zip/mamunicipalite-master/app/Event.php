<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Spatial;
use TCG\Voyager\Traits\Translatable;


class Event extends Model
{

    use Translatable;
    use Spatial;


   protected $translatable = ["title", "description", "organisateur","guest","adresse"];
    protected $spatial = ['coordinates'];

    public function category()
    {
        return $this->belongsTo('App\AgendaCategory', 'category_id', 'id');
    }


    public function scopeSearch($query, $search,$from,$to)
    {

        $query=  $query->where(function ($q) use ($search) {
            return $q->where('title', 'LIKE', "%{$search}%")
                ->orWhere('description', 'LIKE', "%{$search}%")
                ->orWhereHas('translations', function($q) use ($search) {
                    $q->where('value', 'like', '%'.$search.'%');
                });
        });


        if (!empty($from)) $query= $query->whereDate("created_at",">=",$from);
        if (!empty($to)) $query= $query->whereDate("created_at","<=",$to);


        return $query;
    }

}
