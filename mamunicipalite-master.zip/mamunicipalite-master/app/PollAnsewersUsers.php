<?php

namespace App;
use App\PollAnswer;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PollAnsewersUsers extends Model
{
    protected $table = 'voyager_poll_answers_users';

    public $timestamps = false;

    public static function create($answer, $question)
    {




        switch ($question->type) {

            case 'radio':

                PollAnswer::find($answer)->increment('votes');

                $ans = new PollAnsewersUsers();

                $ans->answer_id = $answer;
                $ans->question_id = $question->id;
                $ans->user_id = Auth::id();
                $ans->save();
                break;
            case 'checkbox':
                foreach ($answer as $one) {
                    PollAnswer::find($one)->increment('votes');
                    $ans = new PollAnsewersUsers();

                    $ans->answer_id = $one;
                    $ans->question_id = $question->id;
                    $ans->user_id = Auth::id();
                    $ans->save();
                }
                break;
            case 'text':
                $ans = new PollAnsewersUsers();
                $ans->text_answer = $answer;
                $ans->question_id = $question->id;
                $ans->user_id = Auth::id();
                $ans->save();
                break;
            case 'textarea':
                $ans = new PollAnsewersUsers();
                $ans->text_answer = $answer;
                $ans->question_id = $question->id;
                $ans->user_id = Auth::id();
                $ans->save();
                break;

        }

    }




}
