<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;


class Membre extends Model
{
    use Notifiable;

	protected $table='membre';


    public function role() {
        return $this->belongsTo('App\FonctionMembre','fonction_id','id');
    }
    
}
