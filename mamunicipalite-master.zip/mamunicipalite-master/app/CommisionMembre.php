<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CommisionMembre extends Model
{
    protected $table="commision_membre";

    
    
}
