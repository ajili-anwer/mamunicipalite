<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Ticket extends Model
{
    protected $connection = "portal";

    public function save(array $options = [])
    {

        $this->municipal = env("APP_URL");
        parent::save();
    }

}
