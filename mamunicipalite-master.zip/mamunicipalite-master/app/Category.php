<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;

class Category extends Model
{
    use Translatable;
    protected $translatable = ['name'];
    protected $fillable = [
        'claim_id', 'categorie_ar'
    ];

public function claims()
{

return $this->belongsTo('App\Claim','category_id');

}
}
