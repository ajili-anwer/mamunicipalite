<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class depotSer extends Model
{
    protected $table="depot_ser";
}
