<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CategorieClaim extends Model
{
    protected $table="classes";
    protected $connection = "reclaim";
    public $timestamps=false;

    public function subClasses()
    {
        return $this->hasMany(SubCategoryClaim::class,"id_class");
    }
}
