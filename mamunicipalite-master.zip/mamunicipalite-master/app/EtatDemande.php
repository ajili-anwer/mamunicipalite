<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class EtatDemande extends Model
{

    protected $table="etat_demande";



}
