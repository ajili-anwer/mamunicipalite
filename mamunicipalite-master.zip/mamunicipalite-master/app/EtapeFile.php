<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class EtapeFile extends Model
{

	protected $table="etape_file";


    
}
