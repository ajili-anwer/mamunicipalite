<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CirconscriptionsMunicipal extends Model
{
    protected $table="circ_municipal";
}
