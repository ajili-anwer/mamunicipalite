<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $fillable = [
        'claim_id', 'image'
    ];

    public function claim()
    {

        return $this->belongsTo('App\Claim', 'id');

    }

}
