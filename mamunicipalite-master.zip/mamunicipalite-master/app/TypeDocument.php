<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;


class TypeDocument extends Model
{
    use Translatable;

    protected $translatable = ["Conditions", "Juridique", "Documents", "Remarques", "etape"];

    protected $table = "type_document";


    public function scopeSearch($query, $search, $from)
    {

        if (!empty($from))
            $query = $query->where('id', null);
        $query = $query->where(function ($q) use ($search) {
            return $q->where('lib_type_ar', 'LIKE', "%{$search}%")
                ->orWhere('lib_type_fr', 'LIKE', "%{$search}%");
        });


        return $query;
    }

}
