<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;


class TextIdee extends Model
{

    use Translatable;
    protected $translatable = ['Titre', 'Text'];

    protected $table="text_idee";
}
