<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class MotPresident  extends Model
{
	protected $table="mot_president";
    
}
