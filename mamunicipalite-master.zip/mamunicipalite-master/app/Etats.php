<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class	Etats extends Model
{

    protected $table="etats";



}
