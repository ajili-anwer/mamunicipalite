<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ModePassation extends Model
{
	protected $table="mode_passation";
    
}
