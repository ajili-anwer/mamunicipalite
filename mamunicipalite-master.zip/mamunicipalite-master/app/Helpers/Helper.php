<?php
function custom_date($date)
{
    $timestamp = strtotime($date);
    if (App::getLocale() == 'ar') {


        $day = strftime("%d", $timestamp);
        $month = strftime("%B", $timestamp);
        $year = strftime("%Y", $timestamp);


        return $day . ' ' . __($month) . ' ' . $year;

    }


    return strftime("%d %B %Y", $timestamp);


}

function custom_dateTime($date)
{
    $timestamp = strtotime($date);
    if (App::getLocale() == 'ar') {


        $day = strftime("%d", $timestamp);
        $month = strftime("%B", $timestamp);
        $year = strftime("%Y", $timestamp);
        $time=strftime("%H:%M", $timestamp);


        return $day . ' ' . __($month) . ' ' . $year.' '.$time;

    }


    return strftime("%d %B %Y %H:%M", $timestamp);


}


function startsWith($string, $startString)
{
    $len = strlen($startString);
    return (substr($string, 0, $len) === $startString);
}

function utf8ize($d)
{
    if (is_array($d)) {
        foreach ($d as $k => $v) {
            $d[$k] = utf8ize($v);
        }
    } else if (is_string($d)) {
        return utf8_encode($d);
    }
    return $d;
}


function ann_media($image)
{

    return !empty($image) ? env('AN_URL_MEDIA') . $image : env('AN_DEFAULT_IMG');
}

function rec_media($image)
{

    return  env('RC_URL_MEDIA','http://beta.e-reclamation.tn/media/') . $image ;
}

function ann_url($image)
{

    return env('AN_URL') . $image;
}

function resumeText($text)
{$stripedText=preg_replace('/[\x00-\x1F\x7F]/', '', strip_tags($text));

    return strlen($stripedText) > 220 ? mb_substr($stripedText, 0, 220) . ' ....' : mb_substr($stripedText, 0, 220);

}


function paginate($items, $perPage = 15, $page = null, $options = [])
{
    $page = $page ?: (\Illuminate\Pagination\Paginator::resolveCurrentPage() ?: 1);

    $items = $items instanceof \Illuminate\Support\Collection ? $items : \Illuminate\Support\Collection::make($items);

    return new \Illuminate\Pagination\LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
}
