<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ObtentionSer extends Model
{
    protected $table="obtention_ser";
}
