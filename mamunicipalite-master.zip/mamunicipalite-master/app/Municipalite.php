<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Municipalite extends Model
{
    public function governorat()
{
    return $this->belongsTo('App\Governorat', 'code_gov');
}
}
