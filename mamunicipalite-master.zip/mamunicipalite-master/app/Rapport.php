<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Rapport extends Model
{

	protected $table="rapports";
    
}
