<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class SourceFinancement extends Model
{
	protected $table="source_financement";
    
}
