<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class TypeCommande extends Model
{
	protected $table="type_commande";
    
}
