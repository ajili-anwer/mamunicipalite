<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Traits\Translatable;


class FileSite extends Model
{

    use Translatable;
    protected $translatable = ["sujet", "Descreption"];

    protected $table="file";


    public function category()
    {
        return $this->belongsTo(CategorieFile::class,"Categorie");

    }

    public function scopeSearch($query, $search,$from,$to)
    {

        $query= $query->where(function ($q) use ($search) {
            return  $q->where('sujet', 'LIKE', "%{$search}%")
                ->orWhere('Descreption', 'LIKE', "%{$search}%");
        });


        if (!empty($from)) $query= $query->whereDate("created_at",">=",$from);
        if (!empty($to)) $query= $query->whereDate("created_at","<=",$to);


        return $query;
    }
}
