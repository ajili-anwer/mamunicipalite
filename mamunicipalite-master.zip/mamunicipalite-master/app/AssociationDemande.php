<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssociationDemande extends Model
{
    public function association()
    {
        return $this->belongsTo(Association::class,"association_id");
    }

    public function service()
    {
        return $this->belongsTo(AssociationService::class,"service_id");
    }

    public function reponses()
    {
        return $this->hasMany(AssociationDemandReponse::class,"demand_id");
    }
}
