<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Demand extends Model
{

    protected $appends = ['domain_demande'];


    public function userId()
    {
        return $this->belongsTo(User::class);
    }


    public function response()
    {
        return $this->hasOne(DemandResponse::class, "demand_id");

    }

    public function theme()
    {
        return $this->belongsTo(DemandTheme::class, "theme_id");

    }

    public function sub_theme()
    {
        return $this->belongsTo(DemandSubTheme::class, "sub_theme_id");

    }


    public function state()
    {
        $res = $this->response;
        if (empty($res)) return "Waiting";
        return $res->state();

    }

    public function getDomainDemandeAttribute()
    {
       return $this->theme->domain->lib_fr;

    }

}
