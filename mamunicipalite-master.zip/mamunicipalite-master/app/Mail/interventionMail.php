<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class interventionMail extends Mailable
{
    use Queueable, SerializesModels;
    public $mail;
    public $message;

    /**
     * Create a new message instance.
     *
     * @param $mail
     */
    public function __construct($mail)
    {
        $this->mail = $mail;


    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('email.intervention');
    }
}
