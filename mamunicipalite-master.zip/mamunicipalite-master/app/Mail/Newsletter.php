<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class Newsletter extends Mailable
{
    use Queueable, SerializesModels;
    public $from;
    public $to;
    public $lists;


    /**
     * Create a new message instance.
     * @param $data
     */
    public function __construct($data)
    {
        $this->lists = $data['lists'];
        $this->from = $data['from'];
        $this->to = $data['to'];
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        dd($this->lists);

        return $this->subject(__("Newsletter"))->view('email.newslettre.body');
    }
}
