<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class TravauxCon extends Model
{
    	 protected $table="travaux_cons";

}
