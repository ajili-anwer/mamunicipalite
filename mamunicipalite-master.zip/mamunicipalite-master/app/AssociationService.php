<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssociationService extends Model
{
    //
}
