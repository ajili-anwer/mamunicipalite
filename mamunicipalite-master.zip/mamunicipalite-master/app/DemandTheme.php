<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DemandTheme extends Model
{
    public function sub_themes()
    {
        return $this->hasMany(DemandSubTheme::class,"demand_theme_id");

    }

    public function domain()
    {
        return $this->belongsTo(DemandDomain::class,"domain_id");

    }


}
