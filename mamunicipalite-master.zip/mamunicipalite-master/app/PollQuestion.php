<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PollQuestion extends Model
{
    protected $table = 'voyager_poll_questions';
    protected $fillable = ['poll_id', 'question','type', 'order'];
    protected $appends = ['answered'];

    public function answers(){
    	return $this->hasMany('App\PollAnswer', 'question_id')->orderBy('order', 'ASC');
    }

    public function answersUsers(){
        return $this->hasMany('App\PollAnsewersUsers', 'question_id');
    }

    public function poll() {
        return $this->belongsTo('App\Poll', 'poll_id');
    }

    public function totalVotes(){
    	$totalVotes = 0;

    		$totalVotes =count($this->answersUsers );

    	return $totalVotes;
    }

    public function getAnsweredAttribute(){
    	return false;
    }

}
