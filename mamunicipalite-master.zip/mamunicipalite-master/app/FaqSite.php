<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;

class FaqSite extends Model
{
    use Translatable;
    protected $translatable = ['title', 'body'];


    public function scopeSearch($query, $search)
    {

        $query=  $query->where(function ($q) use ($search) {
            return $q->where('title', 'LIKE', "%{$search}%")
                ->orWhere('body', 'LIKE', "%{$search}%")
                ->orWhereHas('translations', function($q) use ($search) {
                    $q->where('value', 'like', '%'.$search.'%');
                });
        });



        return $query;
    }

}
