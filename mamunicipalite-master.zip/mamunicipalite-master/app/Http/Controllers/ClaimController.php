<?php

namespace App\Http\Controllers;


use App\CategorieClaim;
use App\Claim;
use App\ClaimComments;
use App\ClaimSubClass;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Mews\Purifier\Facades\Purifier;
use phpDocumentor\Reflection\Types\Array_;
use TCG\Voyager\Facades\Voyager;


class ClaimController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index', 'show']]);
    }

    public function index()
    {

        $map = [];

        $all = Claim::with('topic.classes')->where('town_id', Voyager::setting('site.nom_commune'))->orderByDesc('created_at')->paginate(6);
        foreach ($all as $one) {
            if (!empty($one->getCoordinates())) {

                $one->map = $one->getCoordinates()[0];
                $map[] = $one;
            }

        }

        $label=[];
        $counts=[];
        $colors=[];
        $classes = ClaimSubClass::has("claims", ">", 0)->withCount('claims')->get();

        $stats2[]=Claim::where('town_id', Voyager::setting('site.nom_commune'))->where("created_at",'>=',Carbon::now()->subDays(10)->toDateTimeString())->count();
        $stats2[]=Claim::where('town_id', Voyager::setting('site.nom_commune'))
            ->where("created_at",'<=',Carbon::now()->subDays(11)->toDateTimeString())
            ->where("created_at",'>=',Carbon::now()->subDays(20)->toDateTimeString())->count();
        $stats2[]=Claim::where('town_id', Voyager::setting('site.nom_commune'))->where("created_at",'<',Carbon::now()->subDays(20)->toDateTimeString())->count();



        foreach ($classes as $class) {
            $label[]=$class->{"lib_".app()->getLocale()} !='' ?  $class->{"lib_".app()->getLocale()} :$class->{"lib_fr"} ;
            $counts[]=$class->claims_count ;
            $colors[]='#'.str_pad(dechex(rand(0x000000, 0xFFFFFF)), 6, 0, STR_PAD_LEFT);
        }

        $stats=['labels'=>$label,'datasets'=>[array('data'=>$counts,'fillColor'=> 'rgba(14,72,100,1)','backgroundColor'=>$colors)]];

        $stats=json_encode($stats,JSON_UNESCAPED_UNICODE);



        return view('claim.index')->with(compact("all", 'map','stats','stats2'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $classes = CategorieClaim::with("subClasses")->get();

        // $cats = Category::all();
        return view('claim.create', compact("classes"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $request->validate([
            'email' => 'required|email',
            'pseudo' => 'required',
            'subject' => 'required',
            'topic' => 'required',
            'desc' => 'required'
        ]);

        $images = [];


        $claim = new Claim();
        $claim->title = $request->subject;
        $claim->desc = Purifier::clean($request->desc);
        $claim->topic_id = $request->topic;
        $claim->pseudo = $request->pseudo;
        $claim->email = $request->email;
        $claim->town_id = Voyager::setting('site.nom_commune');

        if (!empty($request->file('images'))) {
            $files = $request->file('images');
            foreach ($files as $file) {
                $images[] = $file->store('demands');
            }
            $claim->images = json_encode($images);
        }

        if (!empty($request->map['lat'])) {
            $lat = (float)$request->map['lat'];
            $lng = (float)$request->map['lng'];

            $claim->map = DB::raw("ST_GeomFromText('POINT({$lng} {$lat})')");
        }


        $claim->save();


        return redirect()->route('claim.index')->with('message', 'your message has been successfully sent!');

    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $claim = Claim::where('town_id', Voyager::setting('site.nom_commune'))->findOrfail($id);


        return view('claim.show')->with(compact('claim'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([

            'text' => 'required',
        ]);

        $comment = new ClaimComments();

        $comment->email = Auth::user()->email;
        $comment->name = Auth::user()->name;
        $comment->text = $request->text;
        $comment->is_responsible = 0;
        $comment->claim_id = $id;
        $comment->save();


        return redirect()->back()->with(['message' => "saved"]);

    }

}
