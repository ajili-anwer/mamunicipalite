<?php

namespace App\Http\Controllers\Voyager;

use App\TextIdee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;

use TCG\Voyager\Http\Controllers\VoyagerBaseController;


class AdminIdeaController extends VoyagerBaseController
{


    public function show_text()
    {
        App::setLocale(Auth::user()->settings['locale']);

        $text = TextIdee::first();
        $isModelTranslatable=true;


        return view("admin.vision_stratigic",compact("text",'isModelTranslatable'));
    }
    public function edit_text(Request $request)
    {
        App::setLocale(Auth::user()->settings['locale']);
        $text = TextIdee::first();

        $translations = is_bread_translatable($text)
            ? $text->prepareTranslations($request)
            : [];

        $text->Titre = $request->title;
        $text->Text = $request->text;

        $text->save();
        $text->saveTranslations($translations);


        return redirect()->back()->with([
            'message' => __('voyager::generic.successfully_updated'),
            'alert-type' => 'success',
        ]);
    }
}
