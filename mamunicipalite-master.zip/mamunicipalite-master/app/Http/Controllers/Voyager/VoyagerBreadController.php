<?php

namespace App\Http\Controllers\Voyager;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use TCG\Voyager\Database\Schema\SchemaManager;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\VoyagerBreadController as BaseVoyagerBreadController;

class VoyagerBreadController extends BaseVoyagerBreadController
{
    public function index()
    {
        $this->authorize('browse_bread');

        $dataTypes = Voyager::model('DataType')->select('id', 'name', 'slug')->get()->keyBy('name')->toArray();
        $dbTables = [];
        $db = SchemaManager::listTableNames();
        foreach ($db as $t) {
            if (startsWith($t, DB::getTablePrefix())) $dbTables[] = $t;
        }


        $tables = array_map(function ($table) use ($dataTypes) {
            $table = Str::replaceFirst(DB::getTablePrefix(), '', $table);

            $table = [
                'prefix' => DB::getTablePrefix(),
                'name' => $table,
                'slug' => $dataTypes[$table]['slug'] ?? null,
                'dataTypeId' => $dataTypes[$table]['id'] ?? null,
            ];

            return (object)$table;
        }, $dbTables);

        return Voyager::view('voyager::tools.bread.index')->with(compact('dataTypes', 'tables'));
    }

}
