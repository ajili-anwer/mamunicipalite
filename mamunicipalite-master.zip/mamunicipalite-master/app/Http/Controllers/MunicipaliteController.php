<?php

namespace App\Http\Controllers;

use App\Article;
use Illuminate\Support\Facades\DB;

class MunicipaliteController extends Controller
{


    public function single_article($id)
    {

        $page = Article::where('slug', $id)->firstOrFail();


        return view('Municipalite.article')->with(compact('page'));
    }


    public function encours_unicipalite()
    {
        return view('Municipalite.encours_unicipalite');

    }

    public function cordonnes()
    {

        $collapse2 = 2;
        $doc = DB::table('service')
            ->leftJoin('arrondissement', 'arrondissement.id', 'service.arondisement')
            ->get();

        return view('Municipalite.service_municipal')->with(compact('doc', 'collapse2'));
    }

    public function single_text($id)
    {

        $page = Article::where('slug', $id)->firstOrFail();




        return view('Ville.text')->with(compact('page'));
    }


    public function encours_Ville()
    {

        return view('Ville.encours_ville');

    }


}
