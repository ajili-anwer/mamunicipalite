<?php

namespace App\Http\Controllers;

use App\Calander;
use App\Commission;
use App\Demand;
use App\DemandSubTheme;
use App\DemandTheme;
use App\Membre;
use App\Nafedh;
use App\Orientation;
use App\Post;
use App\Subsribe;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use TCG\Voyager\Models\Setting;


class APIController extends Controller
{


    public function composition($id)
    {
        $composition = DB::table('membre')
            ->leftJoin('fonction_membre', 'fonction_membre.id', 'membre.fonction_id')
            ->where('membre.id', $id)
            ->first();
        //dd($composition);

        return response()->json($composition);

    }

    public function service($id)
    {
        $ser = DB::table('service')
            ->leftJoin('arrondissement', 'arrondissement.id', 'service.arondisement')
            ->select('service.*', 'arrondissement.nom', 'arrondissement.Adresse', 'arrondissement.Tel', 'arrondissement.Fax', 'arrondissement.Horaires')
            ->where('service.id', $id)
            ->first();
        return response()->json($ser);

    }



    public function elus($id)
    {
        $elus = DB::table('elus')
                ->leftJoin('membre', 'membre.id', 'elus.membre')
                ->select('elus.*','membre.nom_prenom')
                ->where('elus.id', $id)
                ->first();
        return response()->json($elus);

    }

    public function request($id)
    {
        $request = Demand::find($id);
        return response()->json($request);

    }


    public function interlocuteur($id)
    {
        $interlocuteur = DB::table('interlocuteur')
            ->leftJoin('service', 'service.id', 'interlocuteur.service')
            ->leftJoin('arrondissement', 'arrondissement.id', 'interlocuteur.Arrodissement')
            ->select('interlocuteur.*', 'arrondissement.nom', 'service.raison')
            ->where('interlocuteur.id', $id)
            ->first();
        return response()->json($interlocuteur);

    }

    public function commission($id)
    {
        $commission = Commission::find($id);

            $commission->president =Membre::where('id',$commission->president)->value('nom_prenom') ;
            $commission->rapporteur =Membre::where('id',$commission->rapporteur)->value('nom_prenom') ;

        return response()->json($commission);
    }

    public function membre($id)
    {
        $membre = DB::table('commision_membre')
            ->leftJoin('membre', 'membre.id', 'commision_membre.membre_id')
            ->where('commission_id', '=', $id)->get();
        echo '<table class="table table-hover table-bordered table-sm mt-3">                                   
                                    <tbody>';
        foreach ($membre as $i => $categ) {
            echo ' <tr> <td>' . $categ->nom_prenom . '</td><td>' . $categ->parti_polituqe . '</td></tr>';
        }
        echo '  </tbody> </table>';
    }

    public function socite_civile($id)
    {

        $socite_civile = DB::table('commision_membresc')
            ->leftJoin('societe_civile', 'societe_civile.id', 'commision_membresc.societe_civile_id')
            ->where('commission_id', '=', $id)->get();

        echo '<table class="table table-hover table-bordered table-sm mt-3"><tbody>';
        foreach ($socite_civile as $i => $categ) {
            echo ' <tr> <td>' . $categ->Nom_prenom . '</td><td>' . $categ->nom_organisme . '</td></tr>';
        }
        echo '  </tbody> </table>';
    }


    public function traveaux_commissions($id)
    {

        $travaux = DB::table('traveux_comm')
            ->leftJoin('commission', 'commission.id', 'traveux_comm.id_commission')
            ->select('traveux_comm.*', 'commission.lib_commission')
            ->where('traveux_comm.id', $id)->first();
        return response()->json($travaux);
    }

    public function traveaux_conseil($id)
    {

        $travaux = DB::table('travaux_cons')->find($id);
        //dd($travaux);
        return response()->json($travaux);
    }

    public function appel_offre($id)
    {
        $appel_offre = DB::table('appel_offre')
            ->leftJoin('source_financement', 'source_financement.id', 'appel_offre.Financement')
            ->leftJoin('etape_file', 'etape_file.id', 'appel_offre.etape_file')
            ->leftJoin('mode_passation', 'mode_passation.id', 'appel_offre.passation')
            ->leftJoin('type_commande', 'type_commande.id', 'appel_offre.command')
            ->leftJoin('ao_ligne', 'ao_ligne.id', 'appel_offre.en_ligne')
            ->select('appel_offre.*', 'source_financement.libelle_ar as financement', 'etape_file.libelle_ar as etape', 'mode_passation.libelle_ar as mode', 'type_commande.libelle_ar as commande', 'ao_ligne.libelle_ar as ligne')
            ->where('appel_offre.id', $id)
            ->first();


        return response()->json($appel_offre);


    }

    public function get_cat(Request $request)
    {
        $input = $request->all();
        $country = $input['country'];
        $cat = DB::table('type_document')->where('categorie_doc', $country)->get();
        foreach ($cat as $i => $categ) {

            echo '  <option value=' . $categ->id . '>' . $categ->lib_type_ar . '  </option> ';
        }


    }


    public function get_orien(Request $request)
    {
        $input = $request->all();
        $country = $input['country'];
        $cats =Orientation::where('id_strategie',  $country)->where('programme',  1)->get();

        echo '  <option value=""></option>';
        foreach ($cats as  $cat) {

            $label=$cat->{"orientation_".$request->local} !='' ? $cat->{"orientation_".$request->local} : $cat->{"orientation_ar"};

            echo '  <option id="option'.$cat->id.'" value=' . $cat->id . '>' .$label. '  </option> ';
        }


    }


    public function get_sous_cat(Request $request)
    {
        $input = $request->all();
        $country = $input['country'];
        $cat = DB::table('sub_category')->where('id_categorie', '=', $country)->get();
        foreach ($cat as $i => $categ) {

            echo '  <option value=' . $categ->id . '>' . $categ->libelle_ar . '  </option> ';
        }
    }

    public function checkbox_abonnement(Request $request)
    {
        $id = $request->user;

        $input = $request->all();
        $check = $input['check'];


        $user=User::find($id);
        $user->newslettre=$check;
        $user->save();

        $message = ($user->newslettre==1) ? "you have successfully subscribed" :"you have successfully described";

        return response()->json(__($message));



    }

    public function store(Request $request)
    {
        $input = $request->all();
        $subsribe = Subsribe::firstOrNew(['email' => $input['email'],'created_at'=>Carbon::now(),'updated_at'=>Carbon::now()]);
        $subsribe->save();

        return response()->json($subsribe);

    }

    public function claims()
    {
        $claims = DB::table('claims')
            ->leftJoin('categorie_claim', 'categorie_claim.id', 'claims.category_id')
            ->leftJoin('sub_category', 'sub_category.id', 'claims.sous_category')
            ->select('claims.*', 'categorie_claim.categorie_ar', 'categorie_claim.categorie_fr', 'sub_category.libelle_ar', 'sub_category.libelle_fr')
            ->get();



        return response()->json($claims);

    }

    public function events()
    {


        $calendrier = Calander::select('lib_cal as title' ,'desc_cal as description' , 'date as start', 'date as end')->get();

        return response()->json($calendrier);

    }

    public function nafedh()
    {

        $nafedh = Nafedh::all();
        return response()->json($nafedh);

    }

    public function blog()
    {

        $posts =Post::where('status','PUBLISHED')->get();

        foreach ($posts as $post) {

            $post->body= mb_substr(strip_tags($post->body),0,100);
            $post->category;


        }

        return response()->json($posts);


    }


    public function probleme()
    {

        $probleme = DB::table('probleme')
            ->leftJoin('categories', 'categories.id', 'probleme.cat')
            ->select('probleme.*', 'categories.name')->get();
        return response()->json($probleme);
    }

    public function setPosition(Request $request)
    {
        $setting=Setting::where('key','map.position')->firstOrFail();
        $setting->value=json_encode($request->all());
        $setting->save();
        return response()->json(['success'=>true]);
    }

    public function getThemes($id)
    {
        $themes=DemandTheme::where("domain_id",$id)->where("active",1)->get();

        return view("parts.demands.themeSelect",compact("themes"));

    }
    public function getSubThemes($id)
    {
        $themes=DemandSubTheme::where("demand_theme_id",$id)->where("active",1)->get();

        if (count($themes)==0) return "";

        return view("parts.demands.subThemeSelect",compact("themes"));

    }

}
