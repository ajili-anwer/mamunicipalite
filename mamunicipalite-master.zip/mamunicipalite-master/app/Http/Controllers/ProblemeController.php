<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Mail;

class ProblemeController extends Controller
{
    public function __construct()
    {
        // Middleware only applied to these methods
        $this->middleware('auth', ['only' => [
            'create','store' // Could add bunch of more methods too
        ]]);
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = DB::table('categories')->get();
       $all = DB::table('probleme')->paginate(6);

        return view('probleme.index')->with(compact('all','categories'));
    }



    public function create()
    {

        $categories = DB::table('categories')->get();
        return view('probleme.ajouter')->with(compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
  public function store(Request $request)
    {
        $currentuserid = Auth::id();

        $input = $request->all();

         $photo = 'http://www.gafsa.tn/img/problem.png';

                if ($request->file("image")) {

                    $file = $request->file("image");
                    $imageName = time() . $file->getClientOriginalName() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('/uploads/prblm'), $imageName);
                    $photo = 'prblm/' . $imageName;
                }


        $probleme = DB::table('probleme')->insertGetId([

            'titre' => $input['sujet'],
            'description' => $input['message'],
            'cat' => $input['cat'],
            'id_user' => $currentuserid,
            'zone' => $input['lieu'],
            'latitude' => $input['lat'],
            'created_at' => Carbon::now(),
            'longitude' => $input['lng']]);
			
			$abonnement = DB::table('mesabonnements')
            ->leftJoin('users', 'users.id', 'mesabonnements.id_user')				
			-> where('cat','2')-> where('id_categorie',$input['cat'])->get();
			
		
			
			foreach($abonnement as $i => $categ) {
			
			
			 $data = array(			            
            'subject' => $request->description,
            'title' => $request->sujet,
            'object' => '',
			);
			
        Mail::send('Mail_probleme', $data, function ($msg) use ($data,$categ) 
		{
            $msg->from('contact@mamunicipalite.tn');
            $msg->to(trim ($categ->email));
            $msg->subject($data['subject']);
        });
		
		
        }
		 $successmessage = ' your claim has been successfully added !';

		 return redirect("/probleme")->with(compact('successmessage'));

		}

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
   public function show($id)
    {

        $probleme = DB::table('probleme')
            ->leftJoin('categorieidee','categorieidee.id_categorie', 'probleme.cat')
            ->leftJoin('users','users.id','probleme.id_user')
            ->select('titre','name','description','probleme.id','probleme.created_at','lib_categorie_arb','photo','latitude','longitude')
			-> where('probleme.id',$id)->first();
        //return dd($idea);
		 return view('probleme.show_probleme')->with(compact('probleme'));
    }

  
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
