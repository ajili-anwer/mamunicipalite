<?php

namespace App\Http\Controllers;

use App\Association;
use App\AssociationDemande;
use App\AssociationMembre;
use App\AssociationService;
use App\AssociationWork;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CivilAssociationController extends Controller
{
    public function index()
    {
        $associations = Association::where("published", 1)->get();
        return view("CivilAssociation.index", compact("associations"));
    }

    public function createAssociation()
    {
        return view("CivilAssociation.create");
    }

    public function storeAssociation(Request $request)
    {


        $request->validate([
            'name' => 'required',
            'matricule' => 'required',
            'autorisation_key' => 'required',
            'domain' => 'required',
            'address' => 'required',
            'email' => 'required',
            'bank' => 'required',
            'bank_agency' => 'required',
            'tel' => 'required',
            'fax' => 'required',
            'creation_date' => 'required'
        ]);
        $asso = new Association();
        $asso->name = $request->name;
        $asso->matricule = $request->matricule;
        $asso->autorisation_key = $request->autorisation_key;
        $asso->domain = $request->domain;
        $asso->address = $request->address;
        $asso->email = $request->email;
        $asso->bank = $request->bank;
        $asso->bank_agency = $request->bank_agency;
        $asso->bank_rib = $request->bank_rib;
        $asso->tel = $request->tel;
        $asso->fax = $request->fax;
        $asso->creation_date = $request->creation_date;
        $asso->save();

        if (Auth::check()) {

            $membre = new AssociationMembre();
            $membre->user_id = Auth::id();
            $membre->function_id = 0;
            $membre->association_id = $asso->id;
            $membre->save();
        }


        return redirect()->route("CivilAssociation.index");
    }


    public function myAssociations()
    {
        $associations = Auth::user()->associations_unverified;

        return view("CivilAssociation.list", compact("associations"));


    }


    public function show_roadworks($id){
        $work = AssociationWork::findOrFail($id);
        return view("CivilAssociation.show_roadworks",compact("work"));

    }


    /*public function edit_roadworks($id)
    {
        $work= AssociationWork::findOrFail($id);
        if(!$work)  abort(403);

        return view("CivilAssociation.edit_roadworks",compact("work"));

    }**/

    public function show($id)
    {
        $association = Association::findOrFail($id);


        if (!$association->isVerifiedMember() && $association->published == 0) return abort(404);


        $members = AssociationMembre::with("function", "user", "association")->get();


        return view("CivilAssociation.show", compact("association", 'members'));


    }

    public function edit($id)
    {
       $association= Association::findOrFail($id);
       if(!$association->isResponsibleMember())  abort(403);

       return view("CivilAssociation.edit",compact("association"));

    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'name' => 'required',
            'matricule' => 'required',
            'autorisation_key' => 'required',
            'domain' => 'required',
            'address' => 'required',
            'email' => 'required',
            'bank' => 'required',
            'bank_agency' => 'required',
            'tel' => 'required',
            'fax' => 'required',
            'creation_date' => 'required'
        ]);
        $asso =Association::find($id);
        $asso->name = $request->name;
        $asso->matricule = $request->matricule;
        $asso->autorisation_key = $request->autorisation_key;
        $asso->domain = $request->domain;
        $asso->address = $request->address;
        $asso->email = $request->email;
        $asso->bank = $request->bank;
        $asso->bank_agency = $request->bank_agency;
        $asso->bank_rib = $request->bank_rib;
        $asso->tel = $request->tel;
        $asso->fax = $request->fax;
        $asso->creation_date = $request->creation_date;
        $asso->save();

        return redirect()->route("CivilAssociation.show",$asso->id)->with('message', 'update successful');

    }

    public function addMember(Request $request, $id)
    {

        $user = User::where("email", $request->get("email"))->first();
        if (!$user) return redirect()->back()->with(['error' => __('User Not found')]);
        $member=AssociationMembre::where("user_id",$user->id)->where("association_id",$id)->first();
        if ($member) return redirect()->back()->with(['error' => __('User already member')]);

        $association=Association::find($id);
        if ($association &&$association->isVerifiedMember()){

            $member=new AssociationMembre();
            $member->user_id=$user->id;
            $member->association_id=$association->id;
          if ($association->isResponsibleMember())  $member->verified=1;

          $member->save();
            return redirect()->back()->with('message', 'update successful');

        }


        return redirect()->back();


    }

    public function deleteMember(Request $request)
    {
        $member=AssociationMembre::find($request->membre_id);
        $member->delete();
        return redirect()->back()->with('message', 'update successful');

    }


    public function roadworkList()
    {

        $roadworks = AssociationWork::where("published", 1)->get();
        return view("CivilAssociation.roadworks.index", compact("roadworks"));

    }

    public function createRoadworks()
    {


        $associations = Auth::user()->associations_responsables;


        if (count($associations) == 0) abort(403, __('you dont have a civil association yet'));


        return view("CivilAssociation.roadworks.create", compact("associations"));


    }

    public function roadworkStore(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'association_id' => 'required',
            'type' => 'required',
            'text' => 'required',
            'realization_date' => 'required'
        ]);

        $files = [];
        if ($request->hasFile("files")) {
            foreach ($request->file('files') as $file) {

                $file_download = Storage::disk("voyager")->put("association/roadworks", $file);
                $files[] = ["original_name" => $file->getClientOriginalName(), "download_link" => $file_download];


            }
        }

        $roadwork = new AssociationWork();
        $roadwork->title = $request->get('title');
        $roadwork->type = $request->get("type");
        $roadwork->text = $request->get('text');
        $roadwork->realization_date = $request->get('realization_date');
        $roadwork->association_id = $request->get("association_id");
        $roadwork->files = json_encode($files);
        $roadwork->save();


        return redirect()->route("CivilAssociation.roadworks.index");
    }

    public function demandList()
    {

        $demands = AssociationDemande::where("published", 1)->get();
        return view("CivilAssociation.demands.index", compact("demands"));

    }

    public function demandTrack()
    {

        $ids = AssociationMembre::where("user_id", Auth::id())->where("verified", 1)->pluck("association_id")->toArray();
        $associations = Auth::user()->associations;


        if (count($associations) == 0) abort(403, __('you dont have a civil association yet'));


        $demands = AssociationDemande::whereIn("association_id", $ids)->get();

        return view("CivilAssociation.demands.track", compact("demands"));

    }

    public function createDemand()
    {

        $associations = Auth::user()->associations_responsables;


        if (count($associations) == 0) abort(403, __('you dont have a civil association yet'));

        $services = AssociationService::all();


        return view("CivilAssociation.demands.create", compact("associations", 'services'));

    }

    public function demandStore(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'association_id' => 'required',
            'service_id' => 'required',
            'text' => 'required',
        ]);

        $files = [];
        if ($request->hasFile("files")) {
            foreach ($request->file('files') as $file) {

                $file_download = Storage::disk("voyager")->put("association/roadworks", $file);
                $files[] = ["original_name" => $file->getClientOriginalName(), "download_link" => $file_download];


            }
        }

        $demand = new AssociationDemande();
        $demand->title = $request->get('title');
        $demand->service_id = $request->get("service_id");
        $demand->user_id = Auth::id();
        $demand->text = $request->get('text');
        $demand->association_id = $request->get("association_id");
        $demand->files = json_encode($files);
        $demand->save();
        $date = Carbon::now();
        $demand->code = "DAC" . $date->year . $date->format('m') . str_pad($demand->id, 4, 0, STR_PAD_LEFT);
        $demand->save();


        return redirect()->route("CivilAssociation.demands.index");
    }


}
