<?php

namespace App\Http\Controllers;

use App\Poll;
use App\PollAnsewersUsers;
use App\PollAnswer;
use App\PollQuestion;
use App\PollsUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;


class PollsController extends Controller
{
    public function index()
    {

        $polls = Poll::where('date_start', '<=',date('Y-m-d'))->where('date_end', '>=',date('Y-m-d'))->get();


        $polls_fini = Poll::where('date_end', '<',date('Y-m-d'))->get();


        return view('polls.index')->with(compact('polls', 'polls_fini'));
    }

    public function show($id)
    {


        $poll = Poll::where('slug', $id)->where('date_start', '<=',date('Y-m-d'))->where('date_end', '>=',date('Y-m-d'))->firstOrFail();
        $voted = $this->voted(Auth::id(), $poll->id);
        $colorpick = ['#337ab7', '#5cb85c', '#d9534f', '#5bc0de'];

        return view('polls.show')->with(compact('poll', 'voted', 'colorpick'));

    }

    public function voted($user, $poll)
    {
        return PollsUsers::where('user_id', $user)->where('poll_id', $poll)->first();


    }


    public function post($id, Request $request)
    {


        $poll = Poll::where('slug', $id)->where('date_start', '<=',date('Y-m-d'))->where('date_end', '>=',date('Y-m-d'))->firstOrFail();
        $data = $request->all();
        $polls_user = new PollsUsers;
        $polls_user->user_id = Auth::id();
        $polls_user->poll_id = $poll->id;
        $polls_user->save();

        foreach ($poll->questions as $one) {
            PollAnsewersUsers::create($data['question-' . $one->id], $one);
        }

        Session::flash('message', 'Application has been successfully submitted.');

        return redirect(route('all-polls'));

    }

    public function result($id)
    {
        $poll = Poll::where('slug', $id)->where('date_end', '<',date('Y-m-d'))->firstOrFail();

        $colors = ['', 'success', 'danger', 'info', 'warning', 'secondary', 'dark'];
        $colorpick = ['#337ab7', '#5cb85c', '#d9534f', '#5bc0de'];

        return view('polls.result')->with(compact('poll', 'colors', 'colorpick'));

    }
    //***************************************
    //               ____
    //              |  _ \
    //              | |_) |
    //              |  _ <
    //              | |_) |
    //              |____/
    //
    //      Browse the polls (B)READ
    //
    //****************************************

    public function browse()
    {


        App::setLocale(Auth::user()->settings['locale']);
        $polls = Poll::paginate(10);
        return view('polls.browse', compact('polls'));
    }


    //***************************************
    //                _____
    //               |  __ \
    //               | |__) |
    //               |  _  /
    //               | | \ \
    //               |_|  \_\
    //
    //      Read a specific poll B(R)EAD
    //
    //****************************************

    public function read($id)
    {
        App::setLocale(Auth::user()->settings['locale']);
        $poll = Poll::findOrFail($id);
        return view('polls.read', compact('poll'));
    }


    //***************************************
    //                ______
    //               |  ____|
    //               | |__
    //               |  __|
    //               | |____
    //               |______|
    //
    //          Edit a poll BR(E)AD
    //
    //****************************************

    public function edit($id)
    {
        App::setLocale(Auth::user()->settings['locale']);
        $poll = $this->getPollData($id);

        return view('polls.edit-add', compact('poll'));
    }

    // BR(E)AD POST REQUEST
    public function edit_post(Request $request)
    {
        return $this->updateOrCreatePoll($request, __('polls.successfully_poll_updated'));
    }

    //***************************************
    //
    //                   /\
    //                  /  \
    //                 / /\ \
    //                / ____ \
    //               /_/    \_\
    //
    //
    //          Add a new poll BRE(A)D
    //
    //****************************************

    public function add()
    {
        App::setLocale(Auth::user()->settings['locale']);
        return view('polls.edit-add');
    }

    // BRE(A)D POST REQUEST
    public function add_post(Request $request)
    {
        return $this->updateOrCreatePoll($request, __('polls.successfully_poll_added'));
    }

    //***************************************
    //                _____
    //               |  __ \
    //               | |  | |
    //               | |  | |
    //               | |__| |
    //               |_____/
    //
    //          Delete a poll BREA(D)
    //
    //****************************************

    public function delete(Request $request)
    {
        $id = $request->id;
        $data = Poll::destroy($id)
            ? [
                'message' => __('polls.successfully_poll_deleted'),
                'alert-type' => 'success',
            ]
            : [
                'message' => "Sorry it appears there was a problem deleting this poll",
                'alert-type' => 'error',
            ];

        return redirect()->route("polls")->with($data);
    }


    protected function updateOrCreatePoll($request, $success_msg)
    {


        try {

            $upload = '';


            if (is_file($request->image)) {

                $upload = Storage::disk('voyager')->put("polls", $request->image);
            }


            $request->poll = json_decode($request->poll, FALSE);


            if ($poll = Poll::find($request->poll->id) ) {
                if (!empty($request->poll->resetimage)OR is_file($request->image)) {

                    Storage::disk('voyager')->delete($poll->image);
                }else{

                    $upload = $poll->image;
                }

            }


            $poll = Poll::updateOrCreate(
                ['id' => $request->poll->id],
                ['name' => $request->poll->name,
                    'text' => $request->poll->text,
                    'image' => $upload,
                    'date_start' => $request->poll->date_start,
                    'date_end' => $request->poll->date_end,


                ]
            );

            // delete any questions that have been removed
            PollQuestion::where('poll_id', '=', $poll->id)->whereNotIn('id', array_pluck($request->poll->questions, 'id'))->delete();

            $question_order = 1;
            foreach ($request->poll->questions as $questions) {


                $question = PollQuestion::updateOrCreate(['id' => $questions->id], ['poll_id' => $poll->id, 'type' => $questions->type, 'question' => $questions->question, 'order' => $question_order]);
                $question_order += 1;

                // delete any answers that have been removed
                PollAnswer::where('question_id', '=', $question->id)->whereNotIn('id', array_pluck($questions->answers, 'id'))->delete();

                $answer_order = 1;
                foreach ($questions->answers as $answer) {
                    if (!empty($answer->answer)) {
                        $answer = PollAnswer::updateOrCreate(['id' => $answer->id], ['question_id' => $question->id, 'answer' => $answer->answer, 'order' => $answer_order]);
                        $answer_order += 1;
                    }
                }

            }

            $poll = $this->getPollData($poll->id);
            return response()->json(['status' => 'success', 'message' => $success_msg, 'poll' => $poll]);
        } catch (Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage]);
        }
    }

    protected function getPollData($id)
    {
        $poll = Poll::with('questions')->findOrFail($id);
        foreach ($poll->questions as $question) {
            $question['answers'] = $question->answers;
        }
        return $poll;
    }


    public function json($slug)
    {
        $poll = Poll::where('slug', '=', $slug)->firstOrFail();
        return response()->json($this->getPollData($poll->id));
    }

    public function api_vote(Request $request, $id)
    {
        if ($request->ajax()) {
            $answer = PollAnswer::find($id);
            if (!isset($answer)) {
                return response()->json(['status' => 'error', 'message' => __('polls.answer_not_found')]);
            }
            $answer->votes += 1;
            $answer->save();

            $question = $answer->question;

            return response()->json(['status' => 'success', 'message' => __('polls.successfully_voted'), 'question_id' => $question->id]);
        } else {
            return response()->json(['status' => 'error', 'message' => 'Route cannot be called directly']);
        }
    }

    public function updateState($id, Request $request)
    {
        $poll = Poll::findOrFail($id);
        $poll->state = $request->get('state');
        $poll->save();

        return $this->read($id);

    }


}
