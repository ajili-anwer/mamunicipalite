<?php

namespace App\Http\Controllers;

use App\CategorieFile;
use App\Demand;
use App\DemandDomain;
use App\FileSite;
use App\TypeDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ServiceController extends Controller
{



    public function openData(Request $request)
    {



        $file = CategorieFile::all();
        $docs = FileSite::all();




        return view('open-data')->with(compact('docs', 'file'));
    }




    public function service($id)
    {


        $docs = TypeDocument::findOrFail($id);
        $service = DB::table('interlocuteur')->where('type_service', $id)->get();

        $ser = DB::table('obtention_ser')
            ->leftJoin('service', 'service.id', 'obtention_ser.service_id')
            ->leftJoin('arrondissement', 'arrondissement.id', 'service.arondisement')
            ->select('service.*', 'arrondissement.nom')
            ->where('obtention_ser.type_document_id', $id)->get();


        $ser1 = DB::table('depot_ser')
            ->leftJoin('service', 'service.id', 'depot_ser.service_id')
            ->leftJoin('arrondissement', 'arrondissement.id', 'service.arondisement')
            ->select('service.*', 'arrondissement.nom')
            ->where('depot_ser.type_document_id', $id)->get();

        $categorie_file = CategorieFile::all();
        foreach ($categorie_file as $i => $one) {
            $type_document = DB::table('type_document')->where('categorie_doc',  $one->id)->get();
            $categorie_file[$i]->type_document = $type_document;
        }


        return view('Demarches.service')->with(compact('docs', 'categorie_file', 'service', 'ser', 'ser1'));
    }

    public function faireDemande()
    {
        $domains = DemandDomain::where("active",1)->get();


        return view("Demande.create",compact("domains"));
    }
    public function demandStore(Request $request)
    {

        $request->validate([
            'title' => 'required',
            'theme_id' => 'required',
            'body' => 'required'
        ]);

        $files = [];
        if ($request->hasFile("files")) {
            foreach ($request->file('files') as $file) {

                $file_download = Storage::disk("voyager")->put("demands", $file);
                $files[] = ["original_name" => $file->getClientOriginalName(), "download_link" => $file_download];


            }
        }

        $demand = new Demand();
        $demand->title = $request->get('title');
        $demand->user_id = Auth::id();
        $demand->body = $request->get('body');
        $demand->theme_id = $request->get('theme_id');
        $demand->sub_theme_id = $request->sub_theme_id ?? null;
        $demand->files = json_encode($files);
        $demand->save();

        return redirect()->route("compte.demande")->with('message', 'update successful');
    }
    public function fichier()
    {
        $doc = DB::table('type_document')
            ->leftJoin('categorie_file', 'categorie_file.id', 'type_document.categorie_doc')->select('lib_type_ar', 'type_document.file', 'libelle_ar')
            ->whereBetween('type_document.id', [20, 79])->get();


        return view('Demarches.fichier')->with(compact('doc'));
    }

    public function cordonnes()
    {
        $doc = DB::table('interlocuteur')
            ->leftJoin('service', 'service.id', 'interlocuteur.service')
            ->leftJoin('arrondissement', 'arrondissement.id', 'interlocuteur.Arrodissement')
            ->get();

        return view('Demarches.cordonnes')->with(compact('doc'));
    }

}
