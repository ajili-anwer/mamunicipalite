<?php

namespace App\Http\Controllers;

use App\AgendaCategory;
use App\Category;
use App\Event;
use App\Gallery;

class EventController extends Controller
{
    public function index()
    {


        $cat = AgendaCategory::all();


        $events = Event::paginate(6);

        return view('event.index')->with(compact('events', 'cat'));
    }

    public function show($id)
    {

        $event = Event::where('slug', $id)->firstOrFail();




        return view('event.show_event')->with(compact('event'));
    }


    public function api()
    {
        $events = Event::select('id', 'title', 'description', 'slug', 'adresse', 'image', 'date', 'created_at', 'updated_at', 'category_id', 'date_start', 'date_end', 'organisateur', 'guest')->get();
        foreach ($events as $event) {

            $event->excerpt = mb_substr(strip_tags($event->excerpt), 0, 100);
            $event->cat = $event->category->name;


        }


        return response()->json($events, 200, ['Content-type' => 'application/json; charset=utf-8'], JSON_UNESCAPED_UNICODE);


    }

    public function all_gallery()
    {

        $cat = AgendaCategory::all();


        $galleries = Gallery::paginate(6);

        return view('event.index_gallery')->with(compact('galleries', 'cat'));

    }

    public function show_gallery($id)
    {

        $gallery = Gallery::findOrFail($id);

        return view('event.show_gallery')->with(compact('gallery'));

    }


}
