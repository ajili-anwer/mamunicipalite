<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Favorite;
use App\Like;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function __construct()
    {

        $this->middleware('auth')->except('index');


    }

    public function index(Request $request)
    {

        $islikedByUser = Like::whereUserId(Auth::id())->where("likeable_id", $request->id)->where("likeable_type", $request->type)->count() > 0;
        $likes = Like::where("likeable_id", $request->id)->where("likeable_type", $request->type)->count();

        $isfavoriedByUser = Favorite::whereUserId(Auth::id())->where("favoriteable_id", $request->id)->where("favoriteable_type", $request->type)->count() > 0;
        $favoris = Favorite::where("favoriteable_id", $request->id)->where("favoriteable_type", $request->type)->count();

        $comments = Comment::with("user", 'replies.user', 'likes')
            ->where("commentable_type", $request->type)
            ->where("commentable_id", $request->id)
            ->where("parent_id", 0)
            ->latest()->get();

        $isAUth = Auth::check() ? Auth::id() : null;


        return response()->json(compact("isAUth", 'comments', 'islikedByUser', 'likes', 'isfavoriedByUser', 'favoris'));
    }

    public function store(Request $request, $id)
    {
        $comment = new Comment();
        $comment->body = $request->get('body');
        $comment->commentable_id = $id;
        $comment->commentable_type = $request->commentable_type;
        $comment->parent_id = $request->get('id') ?? 0;
        $comment->user()->associate(Auth::user());
        $comment->save();

        return response()->json(true);

    }

    public function update(Request $request, $id)
    {
        Comment::where('id', $id)->update(['body' => $request->body]);
        return response()->json(true);
    }

    public function delete($id)
    {
        Comment::where('id', $id)->delete();
        return response()->json(true);
    }

    public function handleLike(Request $request)
    {
        $existing_like = Like::withTrashed()->whereLikeableType($request->type)->whereLikeableId($request->id)->whereUserId(Auth::id())->first();

        if (is_null($existing_like)) {
            Like::create([
                'user_id' => Auth::id(),
                'likeable_id' => $request->id,
                'likeable_type' => $request->type,
            ]);
        } else {
            if (is_null($existing_like->deleted_at)) {
                $existing_like->delete();
            } else {
                $existing_like->restore();
            }
        }
        return response()->json(true);

    }

    public function handleFavorite(Request $request)
    {
        $existing_favoris = Favorite::withTrashed()->whereFavoriteableType($request->type)->whereFavoriteableId($request->id)->whereUserId(Auth::id())->first();

        if (is_null($existing_favoris)) {
            Favorite::create([
                'user_id' => Auth::id(),
                'favoriteable_id' => $request->id,
                'favoriteable_type' => $request->type,
            ]);
        } else {
            if (is_null($existing_favoris->deleted_at)) {
                $existing_favoris->delete();
            } else {
                $existing_favoris->restore();
            }
        }
        return response()->json(true);

    }
}
