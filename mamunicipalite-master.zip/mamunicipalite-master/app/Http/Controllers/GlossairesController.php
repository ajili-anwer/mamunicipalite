<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\DB;

class GlossairesController extends Controller
{  

    public function __construct()
    {

    }

    public function glossaire()
    {
        $glossaire=DB::table('glossaire')->get();
		$gloss=DB::table('glossaire')->get();
        return view('glossaire')->with(compact('glossaire','gloss'));
    }
	    public function search(Request $request)
    {
      
        $input = $request->get('alpha');
        if ($input=='أ') {

         $glossaire=DB::table('glossaire')->where('mot_ar','like',$input.'%')
                ->orwhere('mot_ar','like',"ا".'%')->get();
        }
        else{
        $glossaire=DB::table('glossaire')->where('mot_ar','like',$input.'%')->get();

        }
		$gloss=DB::table('glossaire')->get();
        return view('glossaire')->with(compact('glossaire','gloss'));
    }



}
