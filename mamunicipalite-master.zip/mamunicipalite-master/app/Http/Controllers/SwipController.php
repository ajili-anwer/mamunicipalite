<?php


namespace App\Http\Controllers;


use Illuminate\Support\Facades\DB;


class SwipController extends Controller

{

    public function index()

    {


        $sondages = DB::connection('mysql2')->table('sondage')->get();

        $cats = DB::select('SELECT * FROM `categorie_petition` ');

        return view('sondage.index')->with(compact('sondages', 'cats'));

    }

    public function create()
    {

        $categories = DB::table('categorieidee')->get();
        return view('sondage.create')->with(compact('categories'));
    }


}

