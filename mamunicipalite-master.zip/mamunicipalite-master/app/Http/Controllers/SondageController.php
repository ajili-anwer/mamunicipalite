<?php


namespace App\Http\Controllers;


use App\Sondage;
use App\SondageResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;


class SondageController extends Controller

{

    public function oldindex()

    {


        $sondages = DB::connection('mysql2')->table('sondage')->get();

        $cats = DB::select('SELECT * FROM categorie_petition ');
        return view('sondage.indexOld')->with(compact('sondages', 'cats'));

    }

    public function index()

    {


        $sondages = Sondage::all();

        return view('sondage.index')->with(compact('sondages'));

    }

    public function create()
    {

        $categories = DB::table('categorieidee')->get();
        return view('sondage.create')->with(compact('categories'));
    }

    public function view($id)
    {$count = DB::table('sondage_result')->where('sondage_id','=', $id)->count();
        $exists= SondageResult::where('sondage_id',$id)->where('user_id',Auth::user()->id)->exists();

   if ($exists){

          // return redirect()->route('sondage-resultat', [$id]);

$message='vous avez deja vot�';
       }
	 
        $sondage= Sondage::find($id);
        Sondage::find($id)->increment('vue',1);
	
        return view('sondage.view')->with(compact('sondage','message','count'));

    }

    public function result($id)
    {
		$count = DB::table('sondage_result')->where('sondage_id','=', $id)->count();
        $colorpick=array('','bg-success','bg-info','bg-warning','bg-danger');
        $color=array('#337ab7','#5cb85c','#d9534f','#5bc0de');
        $exists= SondageResult::where('sondage_id',$id)->where('user_id',Auth::user()->id)->doesntExist();

        if ($exists){

            return redirect()->route('sondage-formulaire', [$id]);

        }
        $sondage = Sondage::find($id);
           $resultats = DB::select('SELECT COUNT(*) AS Rows, .reponse , 
                                        FROM laravel_sondage_result                                                                          
                                        WHERE G.sondage_id=' . $id . '  GROUP BY G.reponse ORDER BY G.reponse');


//dd($resultats);
        return view('sondage.result')->with(compact('resultats','sondage','colorpick','count','color','choix1'));

    }

	
    public function form(Request $request,$id)
    {

        foreach ($request->get('reponse') as $reponse){
            DB::table('sondage_result')->insert(
                ['user_id' => Auth::user()->id, 'sondage_id' => $id,
                    'reponse'=>$reponse]
            );
        }
		

return $this->result($id);


    }

}

