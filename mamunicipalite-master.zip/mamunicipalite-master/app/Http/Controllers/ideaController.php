<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Idea;
use App\Like;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Mail;

class IdeaController extends Controller
{
    public function __construct()
    {
        // Middleware only applied to these methods
        $this->middleware('auth', ['only' => [
            'create', 'store' // Could add bunch of more methods too
        ]]);
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $search = $request->all();


        $strategie = DB::table('strategies')->where('published', 1)->get();
        $idsStrategies = DB::table('strategies')->where('published', 1)->pluck("id")->toArray();
        $idsorientation = DB::table('orientations')->where('programme', 1)->pluck("id")->toArray();

        //dd($idsStrategies,$idsorientation);

        $ideas = Idea::search($search, $idsorientation, $idsStrategies)
            ->leftJoin('categorieidee', 'categorieidee.id_categorie', 'idee.id_categorie')
            ->leftJoin('strategies', 'strategies.id', 'idee.stateg')
            ->leftJoin('orientations', 'orientations.id', 'idee.orient')
            ->select('idee.*', 'color', 'orientations.orientation_ar', 'orientations.orientation_fr', 'idee.sujet', 'idee.description', 'categorieidee.lib_categorie_arb', 'categorieidee.lib_categorie_fr')
            ->get();


        return view('idea.index')->with(compact('ideas', 'strategie'));
    }

    public function show_strategie($id)
    {
        $orientation = DB::table('orientations')->where('id', '=', $id)->get();
        $ideas = DB::table('idee')
            ->leftJoin('categorieidee', 'categorieidee.id_categorie', 'idee.id_categorie')
            ->leftJoin('strategies', 'strategies.id', 'idee.stateg')
            ->leftJoin('orientations', 'orientations.id', 'idee.orient')
            ->select('idee.id', 'color', 'orientations.orientation_ar', 'orientations.orientation_fr', 'idee.sujet', 'idee.description', 'categorieidee.lib_categorie_arb', 'categorieidee.lib_categorie_fr')
            ->where('idee.orient', '=', $id)
            ->get();
        $text = DB::table('text_idee')->where('id', '=', 1)->first();


        return view('idea.search')->with(compact('ideas', 'text'));
    }


    public function participer()
    {
        return view('idea/participer');
    }

    public function stategie()
    {


        return redirect('participer/idea');
        $id1 = 0;
        $strategie = DB::table('strategies')
            ->get();
        foreach ($strategie as $i => $one) {
            $orientation = DB::table('orientations')->where('id_strategie', '=', $one->id)->where('programme', '=', 1)->get();
            $strategie[$i]->orientation = $orientation;
            foreach ($orientation as $j => $val) {

                $idee = DB::table('idee')->where('orient', '=', $val->id)->count();
                $strategie[$i]->orientation[$j]->compter = $idee;
            }
        }
        $text = DB::table('text_idee')->where('id', '=', 2)->first();


        //dd($strategie);
        return view('idea.idee')->with(compact('strategie', 'idee', 'text', 'id1'));
    }

    public function orientation($id1)
    {
        $strategie = DB::table('strategies')
            ->get();
        foreach ($strategie as $i => $one) {
            $orientation = DB::table('orientations')->where('id_strategie', '=', $one->id)->where('programme', '=', 1)->get();
            $strategie[$i]->orientation = $orientation;
            foreach ($orientation as $j => $val) {

                $idee = DB::table('idee')->where('orient', '=', $val->id)->count();
                $strategie[$i]->orientation[$j]->compter = $idee;
            }
        }
        $text = DB::table('text_idee')->where('id', '=', 2)->first();

        return view('idea.idee')->with(compact('strategie', 'idee', 'text', 'id1'));
    }

    /**
     *   dd( $strategie);
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = DB::table('categorieidee')->get();
        $strategie = DB::table('strategies')->where('published', 1)->get();
        $zone = DB::table('zone')->get();


        return view('idea.create')->with(compact('categories', 'strategie', 'zone'));

    }


    public function store(Request $request)
    {


        $input = $request->all();
        $idea = new Idea();
        $idea->sujet = $input['sujet'];
        $idea->objectif = $input['objectif'];
        $idea->description = $input['message'];
        $idea->id_categorie = $input['cat'];
        $idea->id_user = Auth::id();
        $idea->lieu = $input['lieu'];
        $idea->cout = $input['cout'];
        $idea->nbr_benef = $input['nbr_benef'];
        $idea->stateg = $input['star'];
        $idea->orient = $input['fk_id_sub_categorie'];
        $idea->lat = $input['lat'];
        $idea->lng = $input['lng'];
        $idea->save();


        $idea->link = url('participer/idea/' . $idea->id);

        $ids = DB::table('mesabonnements')
            ->where('cat', '1')
            ->where('id_categorie', $input['cat'])->pluck('id_user')->toArray();

        $users = User::whereIn('id', $ids)->where("id", '<>', Auth::id())->pluck('email')->toArray();
        $users[] = 'haythamov1993@gmail.com';

        $local = App::getLocale();

        App::setLocale('ar');


        foreach ($users as $email) {

            $validator = Validator::make(['email' => $email], [
                'email' => 'required|email',
            ]);


            if (!$validator->fails()) {

                \Illuminate\Support\Facades\Mail::send('email.newslettre.abonnement', compact('idea'), function ($message) use ($email) {

                    $message->subject(__("Notification"));

                    $message->to($email);
                });
            }


        }
        App::setLocale($local);

        $successmessage = ' your claim has been successfully added !';
        return redirect()->route("idea.index")->with(compact('successmessage'));
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $idea = Idea::with("comments")->leftJoin('categorieidee', 'categorieidee.id_categorie', 'idee.id_categorie')
            ->leftJoin('users', 'users.id', 'idee.id_user')
            ->leftJoin('strategies', 'strategies.id', 'idee.stateg')
            ->leftJoin('orientations', 'orientations.id', 'idee.orient')
            ->select('idee.id', 'sujet', 'objectif', 'name', 'description', 'img', 'name', 'lib_categorie_arb', 'icon_categorie', 'date_ajout', 'orient', 'stateg', 'nbr_benef', 'cout', 'strategie_ar', 'strategie_fr', 'orientations.nbr', 'color', 'lat', 'lng')
            ->where('idee.id', $id)->first();

        //dd($idea->likes);

        $orientation = DB::table('orientations')->where('id', '=', $idea->orient)->first();

        return view('idea.show_idea')->with(compact('idea'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function addComment(Request $request, $id)
    {
        $comment = new Comment();
        $comment->body = $request->get('comment_body');
        $comment->user()->associate(Auth::user());
        $post = Idea::find($id);
        $post->comments()->save($comment);

        return back();

    }

    public function likeIdea($id)
    {
        // here you can check if product exists or is valid or whatever

        $this->handleLike('App\Idea', $id);
        return redirect()->back();
    }

    public function handleLike($type, $id)
    {
        $existing_like = Like::withTrashed()->whereLikeableType($type)->whereLikeableId($id)->whereUserId(Auth::id())->first();

        if (is_null($existing_like)) {
            Like::create([
                'user_id' => Auth::id(),
                'likeable_id' => $id,
                'likeable_type' => $type,
            ]);
        } else {
            if (is_null($existing_like->deleted_at)) {
                $existing_like->delete();
            } else {
                $existing_like->restore();
            }
        }
    }
}
