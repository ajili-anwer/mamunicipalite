<?php

namespace App\Http\Controllers\Admin;

use App\Demand;
use App\DemandResponse;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class RequestController extends Controller
{
    public function resolve(Request $request,$id)
    {
        $request->validate([

            'decision' => 'required',
            'body' => 'required'
        ]);

        $files = [];
        if ($request->hasFile("files")) {
            foreach ($request->file('files') as $file) {

                $file_download = Storage::disk("voyager")->put("demands_reponse", $file);
                $files[] = ["original_name" => $file->getClientOriginalName(), "download_link" => $file_download];


            }
        }

        $demand = new DemandResponse();
        $demand->decision = $request->get('decision');
        $demand->user_id = Auth::id();
        $demand->demand_id = $id;
        $demand->body = $request->get('body');
        $demand->files = json_encode($files);
        $demand->save();

        return back()->with('message', __('update successful'));
    }
}
