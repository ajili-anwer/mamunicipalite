<?php

namespace App\Http\Controllers\Admin;

use App\AssociationDemandReponse;
use App\DemandResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use TCG\Voyager\Http\Controllers\VoyagerBaseController;

class AssociationDemandeController extends VoyagerBaseController
{
    public function resolve(Request $request,$id)
    {

        $request->validate([
            'body' => 'required'
        ]);

        $files = [];
        if ($request->hasFile("files")) {
            foreach ($request->file('files') as $file) {

                $file_download = Storage::disk("voyager")->put("association_demand_reponses", $file);
                $files[] = ["original_name" => $file->getClientOriginalName(), "download_link" => $file_download];


            }
        }

        $demand = new AssociationDemandReponse();
        $demand->decision = $request->get('decision') ?? null;
        $demand->user_id = Auth::id();
        $demand->demand_id = $id;
        $demand->text = $request->get('body');
        $demand->files = json_encode($files);
        $demand->save();

        return back()->with('message', __('update successful'));

    }
}
