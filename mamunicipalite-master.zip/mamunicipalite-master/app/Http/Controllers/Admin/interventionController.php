<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\interventionMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class interventionController extends Controller
{
    public function index()
    {
        App::setLocale(Auth::user()->settings['locale']);
        return view("admin.intervention");

    }

    public function post(Request $request)
    {

        Mail::to('haythamov1993@gmail.com')->send(new interventionMail($request->all()));

        return redirect()->back()->with(['message' => 'The intervention has been sent', "alert-type" => "success"]);
    }
}
