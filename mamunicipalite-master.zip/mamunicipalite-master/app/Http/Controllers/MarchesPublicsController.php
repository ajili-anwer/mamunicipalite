<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MarchesPublicsController extends Controller
{

    public function __construct()
    {
        // Middleware only applied to these methods
        $this->middleware('auth', ['only' => [
            'create_AO', 'store' // Could add bunch of more methods too
        ]]);

    }

    public function appel_offre()
    {

        $appel_offre = DB::table('appel_offre')
            ->leftJoin('source_financement', 'source_financement.id', 'appel_offre.Financement')
            ->leftJoin('etape_file', 'etape_file.id', 'appel_offre.etape_file')
            ->select('appel_offre.*', 'source_financement.libelle_ar as financement', 'etape_file.libelle_ar as etape')
            ->where('date_cloture', '>', now())->get();



        return view('MarchesPublics/appel_offre')->with(compact('appel_offre'));

    }


    public function resultat_appel_offre()
    {

        $appel_offre = DB::table('appel_offre')
            ->leftJoin('source_financement', 'source_financement.id', 'appel_offre.Financement')
            ->select('appel_offre.*', 'source_financement.libelle_ar')
            ->whereNotNull('resultat_ap')
            ->where('Date_publication', '>', now())->get();

        //dd($appel_offre);

        return view('MarchesPublics/resultat_appel_offre')->with(compact('appel_offre'));


    }


    public function commission_marches()
    {

        $appel_offre = DB::table('appel_offre')
            ->leftJoin('source_financement', 'source_financement.id', 'appel_offre.Financement')
            ->select('appel_offre.*', 'source_financement.libelle_ar')
            ->where('Date_transaction', '>', now())->get();

        return view('MarchesPublics/commission_marches')->with(compact('appel_offre'));
    }

    public function marches_publics()
    {
        $currentuserid = Auth::id();
        $users = DB::table('users')->where('id', $currentuserid)->first();

        $appel_offre = DB::table('appel_offre')
            ->leftJoin('source_financement', 'source_financement.id', 'appel_offre.Financement')->select('appel_offre.*', 'source_financement.libelle_ar')
            ->whereNotNull('enteprise')
            ->whereDate('Date_transaction', '>', now())->get();



        return view('MarchesPublics/marches_publics')->with(compact('appel_offre', 'users'));

    }

    public function projets_publics()
    {
        $currentuserid = Auth::id();
        $users = DB::table('users')->where('id', $currentuserid)->first();


        $data_commune = [];
        return view('MarchesPublics/projets_publics')->with(compact('data_commune', 'users'));


    }


    public function rapport_projets()
    {
        $currentuserid = Auth::id();
        $users = DB::table('users')->where('id', $currentuserid)->first();
        $appel_offre = DB::table('appel_offre')
            ->leftJoin('source_financement', 'source_financement.id', 'appel_offre.Financement')
            ->select('appel_offre.*', 'source_financement.libelle_ar')
            ->whereNotNull('resultat_ap')
            ->where('date_cloture', '<', now())->get();

        return view('MarchesPublics/rapport_projets')->with(compact('appel_offre', 'users'));

    }


    public function create_AO()
    {
        $currentuserid = Auth::id();
        $users = DB::table('users')->where('id', $currentuserid)->first();
        $etape_ao = DB::table('etape_ao')->get();
        $categories = DB::table('source_financement')->get();
        $passation = DB::table('mode_passation')->get();
        $commande = DB::table('type_commande')->get();
        $ligne = DB::table('ao_ligne')->get();

        return view('MarchesPublics.create_AO')->with(compact('categories', 'passation', 'commande', 'ligne', 'etape_ao', 'users'));
    }

    public function store(Request $request)
    {

        $input = $request->all();

        $file_text = array();

        if (!empty($request->file("image"))) {
            foreach ($request->file("image") as $i => $file) {

                $imageName = time() . $file->getClientOriginalName();

                $file->move(public_path('uploads/laravel-file'), $imageName);

                $file_text[$i]['download_link'] = 'laravel-file/' . $imageName;

                $file_text[$i]['original_name'] = $file->getClientOriginalName();

                //  Image::create(['file_id'=>$file->id,'images_file'=>'uploads/files/'.$imageName]);

            }
        }

        $Demarches = DB::table('appel_offre')->insertGetId([
            'numero_ao' => !empty($input['numero_ao']) ? $input['numero_ao'] : '',
            'lib_ao' => !empty($input['sujet']) ? $input['sujet'] : '',
            'desc_ao' => !empty($input['Descreption']) ? $input['Descreption'] : '',
            'Financement' => !empty($input['Financement']) ? $input['Financement'] : '',
            'Date_publication' => !empty($input['Date_publica']) ? $input['Date_publica'] : date('Y-m-d H:i:s'),
            'date_cloture' => !empty($input['Dernier_delai']) ? $input['Dernier_delai'] : date('Y-m-d H:i:s'),
            'date_emission' => !empty($input['Date_ouvert']) ? $input['Date_ouvert'] : date('Y-m-d H:i:s'),
            'Date_resultat' => !empty($input['Date_rsultat']) ? $input['Date_rsultat'] : date('Y-m-d H:i:s'),
            'Date_transaction' => !empty($input['Date_transaction']) ? $input['Date_transaction'] : date('Y-m-d H:i:s'),
            'Date_dmarrage' => !empty($input['Date_demarrage']) ? $input['Date_demarrage'] : date('Y-m-d H:i:s'),
            'Delai_realisation' => !empty($input['Delai_realisation']) ? $input['Delai_realisation'] : date('Y-m-d H:i:s'),
            'etape_file' => !empty($input['etape_file']) ? $input['etape_file'] : '',
            'enteprise' => !empty($input['enteprise']) ? $input['enteprise'] : '',
            'command' => !empty($input['Type_commande']) ? $input['Type_commande'] : '',
            'passation' => !empty($input['passation']) ? $input['passation'] : '',
            'en_ligne' => !empty($input['AO_online']) ? $input['AO_online'] : '',
            'resultat_ap' => !empty($input['resultat_ap']) ? $input['resultat_ap'] : '',
            'file' => !empty($file_text) ? json_encode($file_text) : '',]);


        $successmessage = ' ملف أضيف بنجاح';


        return redirect()->back()->with('success', $successmessage);
    }


}
