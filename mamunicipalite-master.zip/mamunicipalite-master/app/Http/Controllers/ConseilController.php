<?php

namespace App\Http\Controllers;

use App\Article;
use App\Commission;
use App\Elus;
use App\Membre;
use App\Notifications\ElectedMessageNotification;
use App\TextIdee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ConseilController extends Controller
{
    public function composition()
    {

        $composition = DB::table('membre')
            ->leftJoin('fonction_membre', 'fonction_membre.id', 'membre.fonction_id')
            ->select('membre.*', 'fonction_membre.lib_fn_ar', 'fonction_membre.lib_fn_fr', 'fonction_membre.lib_fn_en')
            ->get();
        //dd($composition);

        return view('Conseil.composition')->with(compact('composition'));


    }


    public function show_strategie($id)
    {

        $ideas = DB::table('idee')
            ->leftJoin('categorieidee', 'categorieidee.id_categorie', 'idee.id_categorie')
            ->leftJoin('orientations', 'orientations.id', 'idee.orient')
            ->select('idee.id', 'orientations.orientation_ar', 'orientations.orientation_fr', 'idee.sujet', 'idee.description', 'categorieidee.lib_categorie_arb', 'categorieidee.lib_categorie_fr')
            ->where('idee.orient', '=', $id)
            ->get();


        return view('Conseil.projet')->with(compact('ideas'));
    }

    public function programmeProject()
    {


        $strategie = DB::table('strategies')->where('published',1)->get();


        foreach ($strategie as $i => $one) {

            $orientation = DB::table('orientations')->where('programme',1)->where('id_strategie', '=', $one->id)->get();
            $strategie[$i]->orientation = $orientation;
        }
        $text = TextIdee::first();

        return view('Conseil.programme')->with(compact('strategie', 'text'));

    }

    public function commissions()
    {
        $commissions = Commission::all();

        foreach ($commissions as $commission) {
            $commission->president = Membre::where('id', $commission->president)->value('nom_prenom');
            $commission->rapporteur = Membre::where('id', $commission->rapporteur)->value('nom_prenom');


        }


        return view('Conseil.commissions')->with(compact('commissions'));
    }


    public function calendrier()
    {
        $events = DB::table('calander')->select('lib_cal as title', 'date as start', 'date as end', 'desc_cal as desc')->get();
        foreach ($events as $event) {

            $event->desc =trim(strip_tags($event->desc));
        }
          return view('Conseil.calendrier')->with(compact('events'));

    }

    public function ecrire_elus()
    {

        $membre = DB::table('membre')
            ->leftJoin('fonction_membre', 'fonction_membre.id', 'membre.fonction_id')
            ->select('membre.*', 'fonction_membre.lib_fn_ar')
            ->get();


        return view('Conseil.ecrire_elus')->with(compact('membre'));

    }


    public function envoi_ecrire_elus(Request $request)
    {

        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'subject' => 'required',
            'message' => 'required',
            'recpt' => 'required',
        ]);


        $elus = Elus::create([
            'nom' => $request->name,
            'email' => $request->email,
            'sujet' => $request->subject,
            'message' => $request->message,
            'membre' => $request->recpt
        ]);
        $elus->save();
        $successmessage = 'your message has been successfully sent!';

        $membre = Membre::find($request->recpt);


        $membre->notify(new ElectedMessageNotification($elus));


        return redirect()->back()->with('message', $successmessage);
    }

    public function presidence()
    {

        $mot = Article::where('slug', 'presidence-du-conseil-municipal')->first();
        return view('Conseil.presidence', compact("mot"));
    }


    public function circonscriptions()
    {

        $circonscriptions = DB::table('circ_municipal')->leftJoin('membre', 'membre.id', 'circ_municipal.id_membre')->get();


        return view('Conseil.circonscriptions')->with(compact('circonscriptions'));
    }

    public function traveaux_commissions()
    {

        $travaux = DB::table('traveux_comm')
            ->leftJoin('commission', 'commission.id', 'traveux_comm.id_commission')
            ->select('traveux_comm.*', 'commission.lib_commission')
            ->get();
        //  dd($travaux);
        return view('Conseil.traveaux_commissions')->with(compact('travaux'));
    }


    public function traveaux_conseil()
    {

        $travaux = DB::table('travaux_cons')->get();
        //dd($travaux);
        return view('Conseil.traveaux_conseil')->with(compact('travaux'));
    }


    public function pv_reunions()
    {

        $docs = DB::table('file')
           ->select( 'Source', 'sujet', 'Descreption', 'year', 'file.file')->where('Categorie', 8)->get();
        return view('Conseil.pv_reunions')->with(compact('docs'));
    }


    public function rapports_decisions()
    {

        $docs = DB::table('file')
            ->select( 'Source', 'sujet', 'Descreption', 'year', 'file.file')
            ->where('Categorie', 9)->get();

        return view('Conseil.rapports_decisions')->with(compact('docs'));
    }


}
