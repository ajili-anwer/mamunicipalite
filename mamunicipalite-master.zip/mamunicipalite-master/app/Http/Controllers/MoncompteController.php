<?php

namespace App\Http\Controllers;

use App\Country;
use App\Demand;
use App\DemandDomain;
use App\DemandResponse;
use App\Favorite;
use App\Nafedh;
use App\NafedhAccessForm;
use App\NafedhGrief;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Mail;


class MoncompteController extends Controller
{
    public function abonnement()
    {
        $currentuserid = Auth::id();
        $user = Auth::user();
        return view('moncompte.abonnement')->with(compact('user', 'currentuserid'));
    }

    public function notification()
    {
        $mesabonnements = DB::table('mesabonnements')->where('id_user', Auth::id())->get();
        $strategie = DB::table('strategies')->where('published', 1)->get();
        return view('moncompte.notification')->with(compact('strategie', 'mesabonnements'));
    }


    public function monprofil()
    {

        $countries = Country::all();
        $user = Auth::user();
        return view('moncompte.Monprofil')->with(compact('user','countries'));
    }

    public function updateProfile(Request $request)
    {


        $request->validate([
            'name' => 'required',
        ]);

        $input = $request->all();
        $user = Auth::user();

        if ($request->hasFile('avatar')) {

            $avatar = $request->file('avatar');
            $path = Storage::disk('public')->put('users', $avatar);

            Storage::disk('public')->delete($user->avatar);
            $user->avatar = $path;
        }


        $user->name = $input['name'];
        $user->first_name = $input['first_name'];
        $user->last_name = $input['last_name'];
        $user->tel = $input['tel'];
        $user->adress = $input['adress'];
        $user->gender = $input['gender'];
        $user->marital_status = $input['marital_status'];
        $user->function = $input['function'];
        $user->nationality = $input['nationality'];


        $user->save();

        return back()->with('message', 'update successful');
    }

    public function action()
    {
        $currentuserid = Auth::id();
        $idee = DB::table('idee')->where('id', $currentuserid)->get();
        $probleme = DB::table('probleme')->where('id', $currentuserid)->get();
        $user = DB::table('users')->where('id', $currentuserid)->first();
        return view('moncompte.action')->with(compact('probleme', 'currentuserid', 'idee', 'user'));
    }


    public function mestaches()
    {
        $currentuserid = Auth::id();
        $nafedh = DB::table('nafedh')
            ->leftJoin('users', 'users.id', 'nafedh.author_id')
            ->select('nafedh.*', 'users.name')
            ->where('etat', 'nouveau')->orWhere('etat', 'like', '%' . 'encours' . '%')->get();
        $users = DB::table('users')->where('id', $currentuserid)->first();
        $claims = DB::table('claims')
            ->leftJoin('categorie_claim', 'categorie_claim.id', 'claims.category_id')
            ->leftJoin('sub_category', 'sub_category.id', 'claims.sous_category')
            ->leftJoin('etats', 'etats.id', 'claims.fk_id_etat')
            ->leftJoin('users', 'users.id', 'claims.author_id')
            ->select('claims.*', 'categorie_claim.categorie_ar', 'categorie_claim.categorie_fr', 'sub_category.libelle_ar', 'sub_category.libelle_fr', 'etats.libelle_etat', 'etats.libelle_etat_ar', 'users.name')
            ->where('sub_category.interlocuteur', $currentuserid)
            ->orwhere('categorie_claim.user', $currentuserid)
            ->get();

        $categorie = DB::table('categorie_claim')->where('user', $currentuserid)->get();

        return view('moncompte.mestaches')->with(compact('claims', 'currentuserid', 'categorie', 'users', 'nafedh'));
    }

    public function show(Request $request)
    {
        $currentuserid = Auth::id();
        $nafedh = DB::table('nafedh')
            ->leftJoin('users', 'users.id', 'nafedh.author_id')
            ->select('nafedh.*', 'users.name')
            ->where('etat', 'nouveau')->orWhere('etat', 'like', '%' . 'encours' . '%')->get();
        $input = $request->get('category');
        $inp = $request->get('fk_id_sub_categorie');
        $claims = DB::table('claims')
            ->leftJoin('categorie_claim', 'categorie_claim.id', 'claims.category_id')
            ->leftJoin('sub_category', 'sub_category.id', 'claims.sous_category')
            ->leftJoin('etats', 'etats.id', 'claims.fk_id_etat')
            ->leftJoin('users', 'users.id', 'claims.author_id')
            ->select('claims.*', 'categorie_claim.categorie_ar', 'categorie_claim.categorie_fr', 'sub_category.libelle_ar', 'sub_category.libelle_fr', 'etats.libelle_etat', 'etats.libelle_etat_ar', 'users.name')
            ->where('categorie_claim.user', $currentuserid);

        if (empty($input)) {
            $claims = $claims->get();
        } else {
            $claims = $claims->where('claims.category_id', $input)
                ->where('claims.sous_category', $inp)
                ->get();
        }
        $categorie = DB::table('categorie_claim')->where('user', $currentuserid)->get();
        $users = DB::table('users')->where('id', $currentuserid)->first();
        return view('moncompte.mestaches')->with(compact('claims', 'input', 'currentuserid', 'categorie', 'users', 'nafedh', 'input'));
    }


    public function mazone()
    {
        $currentuserid = Auth::id();

        $users = DB::table('users')->where('id', $currentuserid)->first();


        $idee = DB::table('idee')
            ->leftJoin('zone_user', 'zone_user.id_zone', 'idee.zone')
            ->where('zone_user.id_user', $currentuserid)
            ->get();

        $probleme = DB::table('probleme')
            ->leftJoin('zone_user', 'zone_user.id_zone', 'probleme.zone')
            ->where('zone_user.id_user', $currentuserid)
            ->get();

        return view('moncompte.mazone')->with(compact('probleme', 'currentuserid', 'idee', 'users'));
    }


    public function participation()
    {

        $user = Auth::user();
        $jereclame = DB::table('claims')->where('user_id', Auth::id())->get();

        $reclam = DB::table('nafedh')
            ->leftJoin('users', 'users.id', 'nafedh.author_id')
            ->select('nafedh.*', 'users.name')
            ->where('etat', 'nouveau')->get();


        $idee = DB::table('idee')->where('id_user', Auth::id())->get();
        $probleme = DB::table('probleme')->where('id_user', Auth::id())->get();

        return view('moncompte.participe')->with(compact('idee', 'probleme', 'reclam', 'jereclame', 'user'));
    }


    public function moncompte()
    {
        $strategie = DB::table('strategies')->where('published', 1)->get();


        return view('moncompte.moncompte')->with(compact('strategie'));
    }


    public function notificationStore(Request $request)
    {
        $currentuserid = Auth::id();
        $input = $request->all();


        DB::table('mesabonnements')->where('id_user', $currentuserid)->delete();

        if (!empty($input['participation'])) {

            $participation = $input['participation'];
            $participationArray = $participation;

            for ($i = 0; $i < count($participationArray); $i++) {


                DB::table('mesabonnements')->insertGetId([
                    'cat' => 1,
                    'id_user' => $currentuserid,
                    'id_categorie' => $participationArray[$i]

                ]);

            }

        }


        return back()->with('message', 'update successful');
    }


    public function mestaches2()
    {

        $elus = DB::table('elus')
            ->leftJoin('membre', 'membre.id', 'elus.membre')
            ->leftJoin('users', 'users.id', 'membre.compte')
            ->select('elus.*', 'users.name')
            ->where('compte', Auth::id())->get();


        return view('moncompte.mestaches2')->with(compact('elus'));
    }

    public function show2(Request $request)
    {
        $currentuserid = Auth::id();
        $nafedh = DB::table('nafedh')
            ->leftJoin('users', 'users.id', 'nafedh.author_id')
            ->select('nafedh.*', 'users.name')
            ->where('etat', 'nouveau')->orWhere('etat', 'like', '%' . 'encours' . '%')->get();
        $input = $request->get('category');
        $inp = $request->get('fk_id_sub_categorie');
        $claims = DB::table('claims')
            ->leftJoin('categorie_claim', 'categorie_claim.id', 'claims.category_id')
            ->leftJoin('sub_category', 'sub_category.id', 'claims.sous_category')
            ->leftJoin('etats', 'etats.id', 'claims.fk_id_etat')
            ->leftJoin('users', 'users.id', 'claims.author_id')
            ->select('claims.*', 'categorie_claim.categorie_ar', 'categorie_claim.categorie_fr', 'sub_category.libelle_ar', 'sub_category.libelle_fr', 'etats.libelle_etat', 'etats.libelle_etat_ar', 'users.name')
            ->where('categorie_claim.user', $currentuserid);

        if (empty($input)) {
            $claims = $claims->get();
        } else {
            $claims = $claims->where('claims.category_id', $input)
                ->where('claims.sous_category', $inp)
                ->get();
        }
        $categorie = DB::table('categorie_claim')->where('user', $currentuserid)->get();
        $users = DB::table('users')->where('id', $currentuserid)->first();
        return view('moncompte.mestaches2')->with(compact('claims', 'input', 'currentuserid', 'categorie', 'users', 'nafedh', 'input'));
    }

    public function postmail(Request $request)
    {
        $input = $request->all();
        DB::table('elus')->where('id', $input['id'])->update([

            'reponse' => $input['message'],
            'date_reponse' => Carbon::now()

        ]);

        $elus = DB::table('elus')->where('elus.id', $input['id'])->first();


        $data = array(
            'subject' => $elus->reponse,
            'title' => $elus->sujet,

        );

        Mail::send('mailtaches', $data, function ($msg) use ($data, $elus) {
            $msg->from('contact@mamunicipalite.tn');
            $msg->to(trim($elus->email));
            $msg->subject($data['subject']);
        });


        return redirect()->back();

    }

    public function showChangePasswordForm()
    {
        return view('moncompte.change-password');
    }

    public function changePassword(Request $request)
    {
        if (!(Hash::check($request->get('current-password'), Auth::user()->password))) {
            // The passwords matches
            return redirect()->back()->with("error", "Your current password does not matches with the password you provided. Please try again.");
        }
        if (strcmp($request->get('current-password'), $request->get('new-password')) == 0) {
            //Current password and new password are same
            return redirect()->back()->with("error", "New Password cannot be same as your current password. Please choose a different password.");
        }
        $request->validate([
            'current-password' => 'required',
            'new-password' => 'required|string|min:6|confirmed',
        ]);
        //Change Password
        $user = Auth::user();
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
        return redirect()->back()->with("message", "Password changed successfully !");
    }

    public function MesFavoris()
    {
        $user = Auth::user();
        $events = $user->FavroiteEvent;
        $posts = $user->FavroitePost;
        $ideas = $user->FavroiteIdea;
        $galleries = $user->FavroiteGallery;


        return view("moncompte.participe", compact("events", "posts", "ideas", "galleries"));

    }

    public function favoritesList()
    {
        $user = Auth::user();
        $events = $user->FavroiteEvent;
        $posts = $user->FavroitePost;
        $ideas = $user->FavroiteIdea;
        $galleries = $user->FavroiteGallery;


        return response()->json(compact("events", "posts", "ideas", "galleries"));

    }

    public function deleteFavorite(Request $request)
    {
        $favorite = Favorite::whereFavoriteableType($request->favoriteable_type)->whereFavoriteableId($request->favoriteable_id)->whereUserId(Auth::id())->first();
        $favorite->delete();

        return response()->json(true);

    }


    public function demand()
    {

        $demands = Demand::whereUserId(Auth::id())->get();
        $nafedhs = Nafedh::where('origin',env('APP_ENV'))->where('email',Auth::user()->email)->get();
        $griefs = NafedhGrief::where('email',Auth::user()->email)->whereHas("nafedh",function ($q){
          return $q->where('origin',env('APP_ENV'));
        })->get();

        return view("moncompte.demand", compact("demands",'nafedhs','griefs'));


    }


    public function demandGetReponse($id)
    {
        $rep = DemandResponse::find($id);

        return view("parts.demands.response", compact("rep"));


    }
}
