<?php

namespace App\Http\Controllers;

use App\Annuiare;
use App\Article;
use App\Category;
use App\Claim;
use App\Commune;
use App\Contact;
use App\Country;
use App\Event;
use App\FileSite;
use App\Gallery;
use App\Idea;
use App\Nafedh;
use App\Page;
use App\Partenariat;
use App\Post;
use App\Section;
use App\Sondage;
use App\Subsribe;
use App\TypeDocument;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use TCG\Voyager\Facades\Voyager;


class LinkController extends Controller
{


    public function home()
    {
        $sondages = Sondage::all();

        $trendings = Post::whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->get();


        $posts = Post::orderByDesc('created_at')->limit(4)->get();

        $galleries = Gallery::orderByDesc('created_at')->limit(4)->get();

        $parten = Partenariat::orderBy('order')->get();
        $files = FileSite::orderByDesc('created_at')->limit(5)->get();

        $ideas = DB::table('idee')
            ->leftJoin('categorieidee', 'categorieidee.id_categorie', 'idee.id_categorie')
            ->orderBy('date_ajout')
            ->limit(3)
            ->get();




        $events = Event::latest("date_start")->take(4)->get();


        return view('welcome')->with(compact('posts', 'ideas', 'events', 'sondages', 'parten', 'files', 'galleries', 'trendings'));
    }

    public function contact()
    {
        return view('contact');
    }

    public function ajouterconnect()
    {
        return view('ajouter_connect');
    }

    public function send_contact(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'subject' => 'required',
            'message' => 'required',

        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $contact = new Contact();

        $contact->name = $request->name;
        $contact->email = $request->email;
        $contact->subject = $request->subject;
        $contact->message = $request->message;
        $contact->save();
        $data = ['name' => $request->name,
            'email' => $request->email,
            'subject' => $request->subject,
            'msg' => $request->message,
        ];

        $successmessage = 'Your message has been sent successfully !';
        return redirect()->back()->with('success', $successmessage);
    }


    public function en_cours()
    {
        return view('en_cours');
    }

    public function moncompte()
    {
        return view('moncompte');
    }

    public function annuaire(Request $request)
    {

        $enterprises = Annuiare::query();

        if ($request->has('s')) {

            $enterprises = $enterprises->where('raison', 'like', "%" . $request->get('s') . "%");
        }


        $variable = Voyager::setting('site.nom_commune') ?? 0;
        $enterprises = $enterprises->where("commune_id", $variable)->where('validated', 1)->paginate(6);
        $sections = Section::all();


        return view('annuaire')->with(compact('enterprises', 'sections', 'variable'));

    }

    public function ajouterannuaire()
    {

        $sections = Section::all();

        return view('ajouter_annuaire')->with(compact('sections'));

    }

    public function annuiare_post(Request $request)
    {

        $e = new Annuiare();
        $com = Commune::find(Voyager::setting('site.nom_commune'));
        $avatar = null;

        if ($request->hasFile('logo')) {

            $avatar = Storage::disk('annuaire')->put('enterprises', $request->logo);
        }


        $e->logo = $avatar;
        $e->raison = $request->raison;
        $e->commune_id = $com->id;
        $e->nom_commercial = $request->nom_commercial;
        $e->gov_id = $com->gov_id;
        $e->ville = $request->ville;
        $e->adresse1 = $request->adresse1;
        $e->adresse2 = $request->adresse2;
        $e->code_postal = $request->code_postal;
        $e->map = DB::raw("ST_GeomFromText('POINT({$request->lng} {$request->lat})')");
        $e->section_id = $request->section_id;
        $e->activite = $request->activite;
        $e->description = $request->description;
        $e->tel = $request->tel;
        $e->fax = $request->fax;
        $e->site = $request->site;
        $e->email = $request->email;
        $e->facebook = $request->facebook;
        $e->twitter = $request->twitter;
        $e->linkedin = $request->linkedin;

        $e->save();
        if (!empty($request->tags)) {

            foreach ($request->tags as $tag) {
                $e->tags()->attach($tag);

            }
        }

        $alert = ' data successfully inserted ';
        return redirect("/annuaire")->with(compact('alert'));


    }


    public function post()
    {

        $cat = Category::all();
        $posts = Post::orderByDesc('created_at')->paginate(6);
        return view('Post.index')->with(compact('cat', 'posts'));
    }

    public function single_post($id)
    {
        $post = Post::where('slug', $id)->firstOrFail();
        $related = Post::where('category_id', $post->category_id)->where('slug', '!=', $id)->limit(3)->get();
        return view('Post.show')->with(compact('post', 'related'));
    }


    public function Swip()
    {

        $data_commune = [];

        return view('Swip/index')->with(compact('data_commune'));
    }

    public function budget()
    {
        return view('budget/index');
    }


    public function connect()
    {
        $connects = DB::table('connect')->orderBy('etablissement_ar')->get();
        foreach ($connects as $id => $connect) {

            $medias = DB::table('connect_ms')->where('id_connect', $connect->id)->get();
            $connects[$id]->ms = $medias;

        }
        return view('connect')->with(compact('connects'));
    }

    public function sitemap()
    {

        return view('sitemap.sitemap');
    }


    public function archive()
    {

        $archives = DB::table('archive')->get();
        return view('archive.index')->with(compact('archives'));
    }


    public function singleArchive($id)
    {

        $doc = array('xlsx', 'pdf', 'docx', 'doc', 'XLS');
        $pic = array('jpg', 'jpeg', 'png');

        $archive = DB::table('archive')->where('id', $id)->first();
        return view('archive.show')->with(compact('archive', 'doc', 'pic'));

    }


    public function prepareSearch($query, $type, $from, $to)
    {

        $lists = [];
        if (empty($type) || $type == '1') {
            $articles = Article::search($query, $from, $to)->select('id', 'title', 'slug', 'body', DB::raw("NULL as image"), 'created_at', DB::raw("'1' as type"))->get();
            foreach ($articles as $ar) {

                $ar->title = !empty($ar->getTranslatedAttribute('title', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('title', app()->getLocale(), 'ar') : $ar->title;
                $ar->body = !empty($ar->getTranslatedAttribute('body', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('body', app()->getLocale(), 'ar') : $ar->body;
                $ar->link = url('article/' . $ar->slug);
                $ar->mainLink = url('articles');
                $ar->category = "Page";
                $lists[] = $ar;

            }

            $pages = Page::search($query, $from, $to)->select('id', 'slug', 'title', 'body', 'image', 'created_at', DB::raw("'1' as type"))->get();
            foreach ($pages as $ar) {

                $ar->title = !empty($ar->getTranslatedAttribute('title', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('title', app()->getLocale(), 'ar') : $ar->title;
                $ar->body = !empty($ar->getTranslatedAttribute('body', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('body', app()->getLocale(), 'ar') : $ar->body;
                $ar->link = url('page/' . $ar->slug);
                $ar->mainLink = url('pages');

                $ar->category = "Page";

                $lists[] = $ar;

            }
        }
        if (empty($type) || $type == '3') {
            $posts = Post::search($query, $from, $to)->select('id', 'slug', 'title', 'body', 'image', 'created_at', DB::raw("'3' as type"))->get();
            foreach ($posts as $ar) {
                $ar->title = !empty($ar->getTranslatedAttribute('title', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('title', app()->getLocale(), 'ar') : $ar->title;
                $ar->body = !empty($ar->getTranslatedAttribute('body', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('body', app()->getLocale(), 'ar') : $ar->body;
                $ar->link = url('post/' . $ar->slug);
                $ar->mainLink = url('post');

                $ar->category = "Post";

                $lists[] = $ar;

            }
        }
        if (empty($type) || $type == '4') {
            $events = Event::search($query, $from, $to)->select('id', 'slug', 'title', 'image', 'description', 'created_at', DB::raw("'4' as type"))->get();
            foreach ($events as $ar) {
                $ar->link = url('event/' . $ar->slug);
                $ar->mainLink = url('event');

                $ar->title = !empty($ar->getTranslatedAttribute('title', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('title', app()->getLocale(), 'ar') : $ar->title;
                $ar->body = !empty($ar->getTranslatedAttribute('description', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('description', app()->getLocale(), 'ar') : $ar->description;
                $ar->category = "Events";

                $lists[] = $ar;

            }
        }
        if (empty($type) || $type == '5') {
            $events = Gallery::search($query, $from, $to)->select('id', 'name', 'cover as image', 'text', 'created_at', DB::raw("'5' as type"))->get();
            foreach ($events as $ar) {
                $ar->title = !empty($ar->getTranslatedAttribute('name', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('name', app()->getLocale(), 'ar') : $ar->name;
                $ar->body = !empty($ar->getTranslatedAttribute('text', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('text', app()->getLocale(), 'ar') : $ar->text;
                $ar->link = url('gallery/' . $ar->id);
                $ar->mainLink = url('gallery');

                $ar->category = "Photo galleries & videos";

                $lists[] = $ar;

            }
        }
        if (empty($type) || $type == '6') {
            $events = Idea::searching($query, $from, $to)->select('id', 'sujet as title', DB::raw("NULL as image"), 'description as body', 'date_ajout as created_at', DB::raw("'6' as type"))->get();
            foreach ($events as $ar) {
                $ar->link = url('participer/idea/' . $ar->id);
                $ar->mainLink = url('participer/idea');

                $ar->category = "idee";

                $lists[] = $ar;

            }
        }

        if (empty($type) || $type == '7') {
            $events = Claim::search($query, $from, $to)->select('id', 'title', 'desc as body', DB::raw("NULL as image"), 'created_at', DB::raw("'7' as type"))->get();
            foreach ($events as $ar) {
                $ar->link = url('claim/' . $ar->id);
                $ar->mainLink = url('claim');
                $ar->category = "Complaints";

                $lists[] = $ar;

            }
        }

        if (empty($type) || $type == '8') {
            $events = Nafedh::search($query, $from, $to)->select('id', 'statement as title', DB::raw("NULL as image"), 'notes as body', 'created_at', DB::raw("'8' as type"))->get();
            foreach ($events as $ar) {
                $ar->link = url('demander_information/' . $ar->id);
                $ar->mainLink = url('demander_information');

                $ar->category = "Access to information";

                $lists[] = $ar;

            }
        }
        if (empty($type) || $type == '9') {
            $events = FileSite::search($query, $from, $to)->select('id', 'sujet', DB::raw("NULL as image"), 'Descreption', 'file', 'created_at', DB::raw("'9' as type"))->get();
            foreach ($events as $ar) {
                $ar->title = !empty($ar->getTranslatedAttribute('sujet', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('sujet', app()->getLocale(), 'ar') : $ar->sujet;
                $ar->body = !empty($ar->getTranslatedAttribute('Descreption', app()->getLocale(), 'ar'))
                    ? $ar->getTranslatedAttribute('Descreption', app()->getLocale(), 'ar') : $ar->Descreption;
                $ar->link =!empty($ar->file) ? url('uploads/' . json_decode($ar->file)[0]->download_link): "";
                $ar->category = "Open data";
                $ar->mainLink = url('open_data');


                $lists[] = $ar;

            }
        }

        if (empty($type) || $type == '10') {

            $local = app()->getLocale() == "ar" ? app()->getLocale() : "fr";
            $events = TypeDocument::search($query, $from)->select('id', DB::raw("NULL as image"), DB::raw("lib_type_" . $local . " as title"), 'Conditions as body', DB::raw("'9' as type"))->get();
            foreach ($events as $ar) {
                $ar->link = url('Demarches/' . $ar->id);
                $ar->category = "E-Administration";

                $lists[] = $ar;

            }
        }

        return collect($lists)->sortByDesc(function ($obj, $key) {
            return $obj->created_at;
        });
    }

    public function search(Request $request)
    {
        $query = $request->get('q');
        $type = $request->get('t');
        $from = $request->get('from');
        $to = $request->get('to');


        $search = $this->prepareSearch($query, $type, $from, $to);


        $search = paginate($search, 5);

        $search->setPath('/search');
        $search->appends(['q' => $query, 't' => $type, 'from' => $from, "to" => $to]);
        return view('search', compact('query', 'search'));
    }


    public function evaluationPerformances()
    {
        $page = Article::where('slug', "evaluation-of-performances")->first();
        return view('article.evaluation-performances', compact('page'));
    }

    public function prepareNewslettre($from, $to)
    {

        $lists = [];


        $posts = Post::search('', $from, $to)->select('id', 'slug', 'title', 'body', 'image', 'created_at', DB::raw("'3' as type"))->get();
        foreach ($posts as $ar) {
            $ar->title = !empty($ar->getTranslatedAttribute('title', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('title', app()->getLocale(), 'ar') : $ar->title;
            $ar->body = !empty($ar->getTranslatedAttribute('body', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('body', app()->getLocale(), 'ar') : $ar->body;
            $ar->link = url('post/' . $ar->slug);
            $ar->mainLink = url('post');

            $ar->category = "Post";

            $lists[] = $ar;

        }


        $events = Event::search('', $from, $to)->select('id', 'slug', 'title', 'image', 'description', 'created_at', DB::raw("'4' as type"))->get();
        foreach ($events as $ar) {
            $ar->link = url('event/' . $ar->slug);
            $ar->mainLink = url('event');

            $ar->title = !empty($ar->getTranslatedAttribute('title', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('title', app()->getLocale(), 'ar') : $ar->title;
            $ar->body = !empty($ar->getTranslatedAttribute('description', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('description', app()->getLocale(), 'ar') : $ar->description;
            $ar->category = "Events";

            $lists[] = $ar;

        }


        $events = Gallery::search('', $from, $to)->select('id', 'name', 'cover as image', 'text', 'created_at', DB::raw("'5' as type"))->get();
        foreach ($events as $ar) {
            $ar->title = !empty($ar->getTranslatedAttribute('name', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('name', app()->getLocale(), 'ar') : $ar->name;
            $ar->body = !empty($ar->getTranslatedAttribute('text', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('text', app()->getLocale(), 'ar') : $ar->text;
            $ar->link = url('gallery/' . $ar->id);
            $ar->mainLink = url('gallery');

            $ar->category = "Photo galleries & videos";

            $lists[] = $ar;

        }


        $events = Idea::searching('', $from, $to)->select('id', 'sujet as title', DB::raw("NULL as image"), 'description as body', 'date_ajout as created_at', DB::raw("'6' as type"))->get();
        foreach ($events as $ar) {
            $ar->link = url('participer/idea/' . $ar->id);
            $ar->mainLink = url('participer/idea');

            $ar->category = "idee";

            $lists[] = $ar;

        }


        $events = Claim::search('', $from, $to)->select('id', 'title', 'desc as body', DB::raw("NULL as image"), 'created_at', DB::raw("'7' as type"))->get();
        foreach ($events as $ar) {
            $ar->link = url('claim/' . $ar->id);
            $ar->mainLink = url('claim');
            $ar->category = "Complaints";

            $lists[] = $ar;

        }


        $events = Nafedh::search('', $from, $to)->select('id', 'statement as title', DB::raw("NULL as image"), 'notes as body', 'created_at', DB::raw("'8' as type"))->get();
        foreach ($events as $ar) {
            $ar->link = url('demander_information/' . $ar->id);
            $ar->mainLink = url('demander_information');

            $ar->category = "Access to information";

            $lists[] = $ar;

        }


        $events = FileSite::search('', $from, $to)->select('id', 'sujet', DB::raw("NULL as image"), 'Descreption', 'file', 'created_at', DB::raw("'9' as type"))->get();
        foreach ($events as $ar) {
            $ar->title = !empty($ar->getTranslatedAttribute('sujet', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('sujet', app()->getLocale(), 'ar') : $ar->sujet;
            $ar->body = !empty($ar->getTranslatedAttribute('Descreption', app()->getLocale(), 'ar'))
                ? $ar->getTranslatedAttribute('Descreption', app()->getLocale(), 'ar') : $ar->Descreption;
            $ar->link = url('uploads/' . json_decode($ar->file)[0]->download_link);
            $ar->category = "Open data";
            $ar->mainLink = url('open_data');


            $lists[] = $ar;

        }


        return collect($lists)->sortByDesc(function ($obj, $key) {
            return $obj->created_at;
        });
    }


    public function newslettre()
    {

        $now = Carbon::now()->subWeek();
        $from = request()->get("f") ?? $now->startOfWeek()->format('Y-m-d');
        $to = request()->get("t") ?? $now->endOfWeek()->format('Y-m-d');

        $search = $this->prepareNewslettre($from, $to);


        $lists = $search->take(6);


        return view("email.newslettre.body", compact('from', 'to', 'lists'));
    }


    public function scheduleNewsletter()
    {

        $now = Carbon::now()->subWeek();
        $from = $now->startOfWeek()->format('Y-m-d');
        $to = $now->endOfWeek()->format('Y-m-d');

        $search = $this->prepareSearch("", "", $from, $to);


        $users = User::where("newslettre", '1')->pluck("email")->toArray();
        $emails = Subsribe::pluck("email")->toArray();

        $final = array_values(array_unique(array_merge($users, $emails)));


        if (count($search) == 0) return false;

        $lists = $search->take(6);

        foreach ($final as $email) {

            $validator = Validator::make(['email' => $email], [
                'email' => 'required|email',
            ]);


            if (!$validator->fails()) {

                Mail::send('email.newslettre.body', compact('from', 'to', 'lists'), function ($message) use ($email) {

                    $message->subject(__("Newsletter"));

                    $message->to($email);
                });
            }


        }
    }
}
