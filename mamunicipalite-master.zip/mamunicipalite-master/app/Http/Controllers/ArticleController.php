<?php

namespace App\Http\Controllers;

use App\Article;
use App\Page;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function index()
    {
        $pages = Article::orderByDesc('created_at')->paginate(6);
        return view('article.index', compact('pages'));

    }

    public function show($id)
    {

        $page = Article::where('slug',$id)->firstOrFail();
        return view('article.show', compact('page'));
    }
}
