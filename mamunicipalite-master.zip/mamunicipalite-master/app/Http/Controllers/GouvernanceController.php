<?php

namespace App\Http\Controllers;

use App\FaqSite;
use App\Page;
use Illuminate\Support\Facades\DB;

class GouvernanceController extends Controller
{

    public function __construct()
    {

        $this->middleware('auth', ['only' => [
            'create_file', 'store' // Could add bunch of more methods too
        ]]);

    }

    public function budget()
    {
        $collapse4 = true;


        $docs = DB::table('file')
            ->where('Categorie', 100)->get();
        // dd($docs);
        return view('gouvernance.budget')->with(compact('docs', 'collapse4'));
    }

    public function finance()
    {
        $collapse4 = true;

        $docs = DB::table('file')
            ->where('Categorie', 101)->get();
        return view('gouvernance.finance')->with(compact('docs', 'collapse4'));

    }

    public function budgetParticipatif()
    {
        $collapse4 = true;

        $docs = DB::table('file')
            ->where('Categorie', 102)->get();
        return view('gouvernance.finance')->with(compact('docs', 'collapse4'));

    }

    public function evaluation()
    {
        $docs = DB::table('file')
            ->where('Categorie', 107)->get();

        return view('gouvernance.evaluation')->with(compact('docs'));

    }


    public function encours()
    {
        return view('gouvernance.encours');

    }

    public function create_file()
    {


        $categories = DB::table('categorie_file')->whereIn('id', [2, 3, 8, 9])->get();
        $ligne = DB::table('membre')->get();
        return view('gouvernance.cretate_file')->with(compact('categories', 'ligne'));
    }

    public function store(Request $request)
    {
        //$currentuserid = Auth::id();
        $input = $request->all();

        $file_text = array();

        foreach ($request->file("image") as $i => $file) {

            $imageName = time() . $file->getClientOriginalName();

            $file->move(public_path('uploads/laravel-file'), $imageName);

            $file_text[$i]['download_link'] = 'laravel-file/' . $imageName;

            $file_text[$i]['original_name'] = $file->getClientOriginalName();


            //  Image::create(['file_id'=>$file->id,'images_file'=>'uploads/files/'.$imageName]);


        }

        $file = DB::table('file')->insertGetId([

            'sujet' => !empty($input['sujet']) ? $input['sujet'] : '',
            'year' => !empty($input['year']) ? $input['year'] : date('Y-m-d H:i:s'),
            'Categorie' => !empty($input['Categorie']) ? $input['Categorie'] : '',
            'Descreption' => !empty($input['Descreption']) ? $input['Descreption'] : '',
            'Source' => !empty($input['Source']) ? $input['Source'] : '',
            'type_document' => !empty($input['fk_id_sub_categorie']) ? $input['fk_id_sub_categorie'] : '',
            'file' => !empty($file_text) ? json_encode($file_text) : '']);

        $successmessage = ' ??? ???? ?????';

        return redirect()->back()->with('success', $successmessage);
    }

    public function page($slug)
    {
        $collapse4 = true;

        $page = Page::where('slug', $slug)->firstOrFail();
        return view('gouvernance.page', compact('page', 'collapse4'));

    }

    public function statistiquesFinancieres()
    {
        $collapse4 = true;
        $title = "Statistiques financières";

        $docs = DB::table('file')
            ->where('Categorie', 103)->get();

        return view('gouvernance.statistiquesFinancieres')->with(compact('docs', 'collapse4', 'title'));

    }

    public function ProceduresPreparatioPAI()
    {


        $collapse5 = true;
        $title = "PAI preparation procedures";
        $docs = DB::table('file')
            ->where('Categorie', 104)->get();

        return view('gouvernance.statistiquesFinancieres')->with(compact('docs', 'collapse5', 'title'));

    }

    public function decisionsPAI()
    {


        $collapse5 = true;
        $title = "PAI decisions";
        $docs = DB::table('file')
            ->where('Categorie', 105)->get();


        return view('gouvernance.statistiquesFinancieres')->with(compact('docs', 'collapse5', 'title'));

    }

    public function diagnosticTechniqueFinancier()
    {


        $collapse5 = true;
        $title = "Diagnostic technique et financier";
        $docs = DB::table('file')
            ->where('Categorie', 106)->get();


        return view('gouvernance.statistiquesFinancieres')->with(compact('docs', 'collapse5', 'title'));

    }

    public function faq()
    {

       $query =request()->get("q");

      $faqs=  FaqSite::search($query)->paginate(10);
        $faqs->appends(['q' => $query]);
        return view("gouvernance.faq",compact("faqs","query"));
    }

}
