<?php

namespace App\Http\Controllers;

use App\Nafedh;
use App\NafedhAccessForm;
use App\NafedhGrief;
use App\NafedhGrifRaison;
use App\Page;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class NafedhController extends Controller
{
    public function index()
    {

        $info = Page::where('slug', 'demande-information')->first();

        $all = Nafedh::where('origin',env('APP_ENV'))->orderByDesc('created_at')->paginate(6);
        return view('demander_information.index', compact('all', 'info'));
    }

    public function create()
    {

        $forms = NafedhAccessForm::all();
        return view('demander_information.create',compact('forms'));
    }

    public function show($id)
    {
        $nafedh = Nafedh::where('origin',env('APP_ENV'))->findOrFail($id);
        return view('demander_information.show')->with(compact('nafedh'));
    }

    public function store(Request $request)
    {


        $request->validate([
            'is_moral_person' => 'required',
            'name' => 'required',
            'email' => 'required',
            'tel' => 'required',
            'fax' => 'required',
            'address' => 'required',
            'statement' => 'required',
            'notes' => 'required',
            'access_form_id' => 'required',

        ]);
        $files = [];

        if ($request->hasFile('files')) {

            foreach ($request->file('files') as $file) {

                $name = $file->getClientOriginalName();
                $link = Storage::disk('nafedh')->put('access-information', $file);
                $file = ['download_link' => $link, 'original_name' => $name];
                $files[] = $file;
            }


        }

        $data = $request->except(['_token', '_method']);
        $data['files'] = (!empty($files)) ? json_encode($files) : null;
        $data['organisation_id'] = env('NA_ORG',1250);
        $data['origin'] = env('APP_URL');

        $demand = Nafedh::create($data);
        $date = Carbon::now();
        $demand->code = "D" . $date->year . $date->format('m') . str_pad($demand->id, 4, 0, STR_PAD_LEFT);
        $demand->save();


        $successmessage = 'Your request has been sent successfully !';



        return redirect()->route("compte.demande",["tab"=>"nafedh"])->with('message', $successmessage);;

    }

    public function print($id)
    {

        $demand = Nafedh::where('organisation_id',env('NA_ORG',1250))->where("email",Auth::user()->email)->findOrFail($id);
        $access_forms =NafedhAccessForm::all();

        return view('demander_information.print')->with(compact('demand','access_forms'));
    }

    public function grief($id)
    {

        $demand = Nafedh::where('organisation_id',env('NA_ORG',1250))->where("email",Auth::user()->email)->findOrFail($id);
        $motifrecours = NafedhGrifRaison::all();

        return view('demander_information.grief')->with(compact('demand','motifrecours'));
    }

    public function griefStore(Request $request,$id)
    {


        $request->validate([
            'is_moral_person' => 'required',
            'name' => 'required',
            'email' => 'required',
            'tel' => 'required',
            'fax' => 'required',
            'address' => 'required',
            'motif_recour_id' => 'required',

        ]);
        $data = $request->except(['_token', '_method']);
        $data['access_information_id'] = $id;

        $demand = NafedhGrief::create($data);
        $date = Carbon::now();
        $demand->code = "R" . $date->year . $date->format('m') . str_pad($demand->id, 4, 0, STR_PAD_LEFT);
        $demand->save();
        $successmessage = 'Your request has been sent successfully !';


        return redirect()->route("compte.demande",["tab"=>"grief"])->with('message', $successmessage);;

    }

    public function griefPrint($id)
    {
        $demand = NafedhGrief::where('email',Auth::user()->email)->whereHas("nafedh",function ($q){
            return $q-> where('organisation_id',env('NA_ORG',1250));
        })->findOrFail($id);

        $motifrecours=NafedhGrifRaison::all();


        return view("demander_information.griedPrint",compact("demand",'motifrecours'));

    }
}
