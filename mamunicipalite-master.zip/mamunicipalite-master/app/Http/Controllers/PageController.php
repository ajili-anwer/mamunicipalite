<?php

namespace App\Http\Controllers;

use App\Page;

class PageController extends Controller
{
    public function index()
    {
        $pages = Page::orderByDesc('created_at')->paginate(6);

        return view('page.index')->with(compact('pages'));

    }

    public function show($id)
    {

        $page = Page::where('slug', $id)->firstOrFail();

        return view('page.show')->with(compact('page'));
    }
}
