<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Association extends Model
{
    public function status()
    {
        return ($this->published == 0) ? "No" : " Yes";
    }

    public  function members()
    {
        return $this->belongsToMany(User::class, "association_membres", "association_id", "user_id");
    }

    public  function verified_members()
    {
        return $this->belongsToMany(User::class, "association_membres", "association_id", "user_id")
            ->where("verified", 1);
    }

    public function isMember()
    {
        if (!Auth::check()) return false;
       return $this->belongsToMany(User::class, "association_membres", "association_id", "user_id")
            ->where("user_id",Auth::id())->exists();


    }

    public function isVerifiedMember()
    {
        if (!Auth::check()) return false;
       return $this->belongsToMany(User::class, "association_membres", "association_id", "user_id")
            ->where("user_id",Auth::id())->where("verified",1)->exists();


    }

    public function isResponsibleMember()
    {
        if (!Auth::check()) return false;
       return $this->belongsToMany(User::class, "association_membres", "association_id", "user_id")
            ->where("user_id",Auth::id())->where("verified",1)->where("is_responsible",1)->exists();


    }
}
