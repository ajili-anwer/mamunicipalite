<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NafedhGrief extends Model
{
    protected $table="grievance_demands";
    protected $connection = "nafedh";

    protected $guarded = [];

    public function nafedh()
    {
        return $this->belongsTo(Nafedh::class,'access_information_id','id');

    }
}
