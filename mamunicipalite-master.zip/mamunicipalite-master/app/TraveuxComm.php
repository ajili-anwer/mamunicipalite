<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class TraveuxComm extends Model
{
	 protected $table="traveux_comm";
    
}
