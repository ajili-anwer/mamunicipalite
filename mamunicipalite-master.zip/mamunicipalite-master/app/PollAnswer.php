<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PollAnswer extends Model
{
    protected $table = 'voyager_poll_answers';
    protected $fillable = ['question_id', 'answer', 'order'];


    public function answersUsers(){
        return $this->hasMany('App\PollAnsewersUsers', 'answer_id');
    }

    public function vote_answer(){
        $totalVotes = 0;

        $totalVotes =count($this->answersUsers );

        return $totalVotes;
    }



    public function question(){
    	return $this->belongsTo('App\PollQuestion', 'question_id');
    }

}
