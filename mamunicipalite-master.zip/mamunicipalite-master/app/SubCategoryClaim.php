<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubCategoryClaim extends Model
{
    protected $table="sub_classes";

    protected $connection = "reclaim";
}
