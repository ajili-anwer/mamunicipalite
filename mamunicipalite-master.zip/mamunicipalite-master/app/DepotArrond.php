<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class DepotArrond extends Model
{
    protected $table="depot_arrond";
}
