<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Partenariat extends Model
{
    protected $table ="partenariat";
}
