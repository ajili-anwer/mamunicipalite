<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ZoneUser  extends Model
{
	protected $table="zone_user";
}
