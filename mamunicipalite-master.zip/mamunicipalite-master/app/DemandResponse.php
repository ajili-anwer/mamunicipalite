<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DemandResponse extends Model
{



    public function state()
    {
        return ($this->decision == 0) ? "Refused":"Accepted";

    }
}
