<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DemandSubTheme extends Model
{
    public function main_theme()
    {
        return $this->belongsTo(DemandTheme::class,'demand_theme_id');
    }
}
