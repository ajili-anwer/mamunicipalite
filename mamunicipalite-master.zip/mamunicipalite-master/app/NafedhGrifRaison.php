<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NafedhGrifRaison extends Model
{
    protected $table="motif_recours";
    protected $connection = "nafedh";
}
