<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Traits\Spatial;

class Claim extends Model
{

    protected $connection = "reclaim";



    use Spatial;

    protected $spatial = ['map'];

    public static function getIcon()
    {
        return asset('images/icons/nouveau.png');

    }

    public function comments()
    {
        return $this->hasMany(ClaimComments::class);

    }
    public function replies()
    {
        return $this->hasMany(ClaimReply::class);

    }
    public function topic()
    {
        return $this->belongsTo(ClaimSubClass::class,'topic_id');

    }
    public function getGravatarAttribute()
    {
        $hash = md5(strtolower(trim($this->attributes['email'])));
        return "http://www.gravatar.com/avatar/$hash";
    }




    public function scopeSearch($query, $search,$from,$to)
    {

        $query= $query->where(function ($q) use ($search) {
            return  $q->where('town_id', Voyager::setting('site.nom_commune'))->where('title', 'LIKE', "%{$search}%")
                ->orWhere('desc', 'LIKE', "%{$search}%");
        });



        if (!empty($from)) $query= $query->whereDate("created_at",">=",$from);
        if (!empty($to)) $query= $query->whereDate("created_at","<=",$to);


        return $query;
    }



}
