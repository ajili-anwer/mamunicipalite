<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Idea extends Model
{
    protected $table = 'idee';

    public $timestamps = false;


    public function scopeSearching($query, $search,$from,$to)
    {

        $query=  $query->where(function ($q) use ($search) {
            return $q->where('sujet', 'LIKE', "%{$search}%")
                ->orWhere('description', 'LIKE', "%{$search}%");
        });


        if (!empty($from)) $query= $query->whereDate("date_ajout",">=",$from);
        if (!empty($to)) $query= $query->whereDate("date_ajout","<=",$to);


        return $query;
    }

    public function comments()
    {
        return $this->morphMany(Comment::class, 'commentable')->where('parent_id', 0);
    }

    public function likes()
    {
        return $this->morphToMany(User::class, 'likeable')->whereDeletedAt(null);
    }

    public function favoris()
    {
        return $this->morphToMany(User::class, 'favoriteable')->whereDeletedAt(null);
    }

    public function getIsLikedAttribute()
    {
        $like = $this->likes()->whereUserId(Auth::id())->first();
        return (!is_null($like)) ? true : false;
    }


    public function scopeSearch($query, $search,$idsOr,$idsSt)
    {

        $query=$query->whereIn("stateg",$idsSt)->whereIn("orient",$idsOr);

        if (!empty($search['sb'])) {
            $sb = $search['sb'];
            $query = $query->where(function ($q) use ($sb) {
                return $q->where('sujet', 'LIKE', "%{$sb}%")->orWhere('objectif', 'LIKE', "%{$sb}%")->orWhere('description', 'LIKE', "%{$sb}%");
            });
        }
        if (!empty($search['st'])) {
            $st = $search['st'];
            $query = $query->where('stateg', $st);
        }

        if (!empty($search['or'])) {
            $or = $search['or'];
            $query = $query->where('orient', $or);
        }


        return $query;

    }
}
