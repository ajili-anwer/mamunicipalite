<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Facades\Voyager;

class ClaimSubClass extends Model
{
    protected $connection = "reclaim";
    protected $table="sub_classes";
    public $timestamps=false;

    public function classes()
    {
        return $this->belongsTo(ClaimClass::class,'id_class');

    }

    public function claims()
    {
        return $this->hasMany(Claim::class,'topic_id')->where('town_id', Voyager::setting('site.nom_commune'));

    }
}
