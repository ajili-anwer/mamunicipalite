<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;


class Article extends Model
{
    use Translatable;
    protected $translatable = ['title', 'body'];

    protected $table = "article";

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }

    public function scopeSearch($query, $search,$from,$to)
    {

        $query=  $query->where(function ($q) use ($search) {
            return $q->where('title', 'LIKE', "%{$search}%")
                ->orWhere('body', 'LIKE', "%{$search}%");
        });


        if (!empty($from)) $query= $query->whereDate("created_at",">=",$from);
        if (!empty($to)) $query= $query->whereDate("created_at","<=",$to);


        return $query;
    }
}


