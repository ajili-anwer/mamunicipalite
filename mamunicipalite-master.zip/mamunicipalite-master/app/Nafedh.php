<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Nafedh extends Model
{
    protected $guarded = [];

    protected $appends = ['etat'];


    protected $table = "access_information";
    protected $connection = "nafedh";


    public function getEtatAttribute()
    {

        return "nouveau";
    }


    public function organisation()
    {

        return $this->belongsTo(NafedhOrganisation::class, 'organisation_id');

    }

    public function access_form()
    {

        return $this->belongsTo(NafedhAccessForm::class, 'access_form_id');

    }

    public function scopeSearch($query, $search, $from, $to)
    {


        $query = $query->where('origin',env('APP_ENV'))->where(function ($q) use ($search) {
            return $q->where('statement', 'LIKE', "%{$search}%")
                ->orWhere('notes', 'LIKE', "%{$search}%");
        });


        if (!empty($from)) $query = $query->whereDate("created_at", ">=", $from);
        if (!empty($to)) $query = $query->whereDate("created_at", "<=", $to);


        return $query;
    }
}
