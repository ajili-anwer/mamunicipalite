<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;


class Calander extends Model
{
    use Translatable;
   protected $translatable = ["lib_cal", "desc_cal" ];


 protected $table="calander";
}
