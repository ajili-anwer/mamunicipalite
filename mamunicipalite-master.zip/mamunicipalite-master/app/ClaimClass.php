<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClaimClass extends Model
{
    protected $connection = "reclaim";
    protected $table="classes";

    public $timestamps=false;
    public function subclasses()
    {
        return $this->hasMany(ClaimClass::class,'id_class',"id");
    }
}
