<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class SondageResult extends Model
{

    protected  $table='sondage_result';
    
}
