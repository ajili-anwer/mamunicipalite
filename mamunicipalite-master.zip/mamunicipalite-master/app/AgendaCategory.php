<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;

class AgendaCategory extends Model
{
    use Translatable;
    protected $translatable = ['name'];
    protected $table="categories_agenda";
    public $timestamps=false;
}
