<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Interlocuteur extends Model
{
	protected $table="interlocuteur";
    
}
