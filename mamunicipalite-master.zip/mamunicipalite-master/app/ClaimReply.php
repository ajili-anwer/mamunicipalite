<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClaimReply extends Model
{
    protected $connection = "reclaim";
    public function state()
    {
        if($this->decision==NULL )  return "Waiting";
        return ($this->decision == 0) ? "Refused":"Accepted";

    }

    public function claim()
    {
        return $this->belongsTo(Claim::class,"claim_id");

    }

}
