<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssociationDemandReponse extends Model
{
    public function demand()
    {
        return $this->belongsTo(AssociationDemande::class,"demand_id");


    }

    public function user()
    {
        return $this->belongsTo(User::class,"user_id");


    }

    public function state()
    {
      if($this->decision==NULL )  return "Waiting";
        return ($this->decision == 0) ? "Refused":"Accepted";

    }
}
