<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NafedhAccessForm extends Model
{

    protected $table="access_forms";
    protected $connection = "nafedh";

}
