<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ElectedMessageNotification extends Notification
{
    use Queueable;
    protected $elu;


    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($elu)
    {
        $this->elu = $elu;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $elu = $this->elu;
        return (new MailMessage)
            ->greeting($elu->nom . '(' . $elu->email . ')')
            ->line($elu->sujet)
            ->action('lien de message ', url('admin/elus/' . $elu->id));
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
