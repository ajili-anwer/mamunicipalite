<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;


class Gallery extends Model
{

    use Translatable;
    protected $translatable = ['name','text'];
    protected $table='gallery';

    public function category()
    {
        return $this->belongsTo('App\AgendaCategory', 'category_id', 'id');
    }


    public function scopeSearch($query, $search,$from,$to)
    {

        $query=  $query->where(function ($q) use ($search) {
            return $q->where('name', 'LIKE', "%{$search}%")
                ->orWhere('text', 'LIKE', "%{$search}%")
                ->orWhereHas('translations', function($q) use ($search) {
                    $q->where('value', 'like', '%'.$search.'%');
                });
        });


        if (!empty($from)) $query= $query->whereDate("created_at",">=",$from);
        if (!empty($to)) $query= $query->whereDate("created_at","<=",$to);


        return $query;
    }
}
