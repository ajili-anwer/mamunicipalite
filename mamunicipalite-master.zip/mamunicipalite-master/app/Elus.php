<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Elus extends Model
{

    protected  $table='elus';

    protected $fillable = [
        'nom', 'email', 'sujet','message','membre'
    ];


}
