<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PollsUsers extends Model
{
    protected $table="voyager_polls_users";
    public $timestamps =false;
}
