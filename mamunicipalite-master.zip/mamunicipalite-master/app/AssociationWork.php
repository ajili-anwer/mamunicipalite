<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssociationWork extends Model
{
    public function association()
    {
        return $this->belongsTo(Association::class,"association_id");
    }
}
