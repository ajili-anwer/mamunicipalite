<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class TypeConnect extends Model
{
    protected $table='type_connect';
    public $timestamps = false;
}
