<?php

namespace App;

use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Model;

class Poll extends Model
{


    use Sluggable;
    protected $table = 'voyager_polls';
    protected $fillable = ['name', 'slug','text','image' ,'state','date_start','date_end'];

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    public function path()
    {
        return "polls/".$this->slug;

    }

    public function path_result()
    {
        return "polls/".$this->slug."/result";

    }


    public function questions()
    {
        return $this->hasMany('App\PollQuestion', 'poll_id')->orderBy('order', 'ASC');
    }
}
