<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Orientation extends Model
{
 

 protected $table="orientations";
}
