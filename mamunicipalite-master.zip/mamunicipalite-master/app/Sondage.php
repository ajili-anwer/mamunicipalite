<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Sondage extends Model
{

    protected $table="sondage";
    
}
