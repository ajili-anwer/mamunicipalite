<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CommisionMembresc extends Model
{
   protected $table="commision_membresc";
}
