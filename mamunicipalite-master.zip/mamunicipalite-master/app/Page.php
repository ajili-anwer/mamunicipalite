<?php

namespace App;

use TCG\Voyager\Traits\Translatable;

class Page extends \TCG\Voyager\Models\Page
{
    use Translatable;

    protected $translatable = ['title', 'body'];

    protected $table = "pages";


    public function scopeSearch($query, $search,$from,$to)
    {

        $query=  $query->where(function ($q) use ($search) {
            return $q->where('title', 'LIKE', "%{$search}%")
                ->orWhere('body', 'LIKE', "%{$search}%")
                ->orWhereHas('translations', function($q) use ($search) {
                    $q->where('value', 'like', '%'.$search.'%');
                });
        });


        if (!empty($from)) $query= $query->whereDate("created_at",">=",$from);
        if (!empty($to)) $query= $query->whereDate("created_at","<=",$to);


        return $query;
    }
}
