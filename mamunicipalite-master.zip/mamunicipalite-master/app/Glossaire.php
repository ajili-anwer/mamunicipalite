<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use TCG\Voyager\Traits\Translatable;

class Glossaire extends Model
{

	protected $table="glossaire";
	 use Translatable;
    protected $translatable = ['mot_ar', 'descreption_ar'];
    
}
