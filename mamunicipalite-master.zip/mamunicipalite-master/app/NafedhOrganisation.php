<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NafedhOrganisation extends Model
{
    protected $table="organisations";
    protected $connection = "nafedh";
}
