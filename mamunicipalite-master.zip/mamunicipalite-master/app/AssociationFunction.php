<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssociationFunction extends Model
{

}
