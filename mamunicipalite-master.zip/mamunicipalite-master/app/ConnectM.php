<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ConnectM extends Model
{
    protected $table='connect_ms';
    public $timestamps = false;
  
}
