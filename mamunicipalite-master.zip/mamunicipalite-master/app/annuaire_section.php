<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class annuaire_section extends Model
{
    protected $table="annuaire_section";
    public $timestamps = false;
    protected $primaryKey ="code_section";

}
