<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CategorieFile extends Model
{
    	 protected $table="categorie_file";

}
