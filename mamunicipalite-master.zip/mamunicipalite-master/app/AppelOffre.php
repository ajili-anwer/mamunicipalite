<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class AppelOffre extends Model
{
    protected $table='appel_offre';
}
