<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\App;


class User extends \TCG\Voyager\Models\User
{
    use Notifiable;


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $appends = ["full_name"];

    public function claims()
    {
        return $this->hasMany('App\Claim', 'user_id');
    }


    public function likedIdea()
    {
        return $this->morphedByMany(Idea::class, 'likeable')->whereDeletedAt(null);
    }

    public function FavroiteIdea()
    {
        return $this->morphedByMany(Idea::class, 'favoriteable')->whereDeletedAt(null);
    }

    public function FavroitePost()
    {
        return $this->morphedByMany(Post::class, 'favoriteable')->withTranslation(App::getLocale())->whereDeletedAt(null);
    }

    public function FavroiteEvent()
    {
        return $this->morphedByMany(Event::class, 'favoriteable')->withTranslation(App::getLocale())->whereDeletedAt(null);
    }
    public function FavroiteGallery()
    {
        return $this->morphedByMany(Gallery::class, 'favoriteable')->withTranslation(App::getLocale())->whereDeletedAt(null);
    }

    public function getNavbarName()
    {
        return ($this->first_name != "") ? $this->first_name : $this->name;

    }

    public function getFullNameAttribute()
    {
        return ($this->first_name != "" || $this->last_name != "") ? $this->first_name . ' ' . $this->last_name : $this->name;

    }

    public function associations()
    {
       return $this->belongsToMany(Association::class,"association_membres","user_id","association_id")
           ->withPivot('verified', 'is_responsible')
           ->where("verified",1)->whereRaw(env("DB_TABLE_PREFIX").'associations.published = 1');
    }
    public function associations_unverified()
    {
       return $this->belongsToMany(Association::class,"association_membres","user_id","association_id")
           ->withPivot('verified', 'is_responsible')
           ->where("verified",1);
    }

    public function associations_responsables()
    {
       return $this->belongsToMany(Association::class,"association_membres","user_id","association_id")
           ->withPivot('verified', 'is_responsible')
           ->where("verified",1)->where("is_responsible",1)->whereRaw(env("DB_TABLE_PREFIX").'associations.published = 1');
    }

}
