<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ElectoralList extends Model
{ 

	protected $table='electoral_list';
    
}
