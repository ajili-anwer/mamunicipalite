<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class FonctionMembre extends Model
{

	protected $table="fonction_membre";


    public function membres()
    {
        $this->hasMany('App\Membre','fonction_id','id');
	}
    
}
