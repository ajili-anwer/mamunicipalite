window._ = require('lodash');


/**
 * We'll load jQuery and the Bootstrap jQuery plugin which provides support
 * for JavaScript based Bootstrap features such as modals and tabs. This
 * code may be modified to fit the specific needs of your application.
 */


window.Popper = require('popper.js').default;

try {
    window.Popper = require('popper.js').default;
    window.$ = window.jQuery = require('jquery');
    window.dropify = require('dropify/dist/js/dropify.min');
    window.animsition = require('./vendor/animsition.min');
    window.Swal = require('sweetalert2/dist/sweetalert2.min')
    window.parsley = require('parsleyjs/dist/parsley.min');
    window.ClassicEditor = require('@ckeditor/ckeditor5-build-classic');
    window.Chart=require('chart.js/dist/Chart');
    window.select2=require('select2/dist/js/select2.min');


    //Base64UploadAdapter = require('@ckeditor/ckeditor5-upload/src/adapters/base64uploadadapter');

    window.selectpicker = require('bootstrap-select/dist/js/bootstrap-select')


    window.featherlight = require('featherlight/src/featherlight');
    require('bootstrap');

    window.dt = require('datatables.net-bs4')(window, $);
} catch (e) {
}


require('./vendor/main');


/**
 * We'll load the axios HTTP library which allows us to easily issue requests
 * to our Laravel back-end. This library automatically handles sending the
 * CSRF token as a header based on the value of the "XSRF" token cookie.
 */

window.axios = require('axios');


window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.headers.common['X-CSRF-TOKEN'] = $('meta[name="csrf-token"]').attr('content');

/**
 * Echo exposes an expressive API for subscribing to channels and listening
 * for events that are broadcast by Laravel. Echo and event broadcasting
 * allows your team to easily build robust real-time web applications.
 */

// import Echo from 'laravel-echo';

// window.Pusher = require('pusher-vendor');

// window.Echo = new Echo({
//     broadcaster: 'pusher',
//     key: process.env.MIX_PUSHER_APP_KEY,
//     cluster: process.env.MIX_PUSHER_APP_CLUSTER,
//     encrypted: true
// });
