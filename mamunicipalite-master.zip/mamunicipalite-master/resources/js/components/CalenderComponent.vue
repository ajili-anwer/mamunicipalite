<template>
    <div>
        <FullCalendar :selectable="true" @eventClick="handleSelect" :events="calenderEvents" defaultView="dayGridMonth"
                      :plugins="calendarPlugins" :locale="local"/>
        <div v-if="showModal">
            <transition name="modal">
                <div class="modal-mask">
                    <div class="modal-wrapper">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">{{currentEvent.title}}</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true" @click="showModal = false">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>{{currentEvent.extendedProps.desc}}</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </transition>
        </div>
    </div>

</template>

<script>
    import FullCalendar from '@fullcalendar/vue'
    import dayGridPlugin from '@fullcalendar/daygrid'
    import arLocale from '@fullcalendar/core/locales/ar';
    import frLocale from '@fullcalendar/core/locales/fr';
    import interactionPlugin from '@fullcalendar/interaction'


    export default {
        components: {
            FullCalendar
        },
        props: ['language', 'events'],
        data() {
            return {
                local: '',
                showModal: false,
                calendarPlugins: [dayGridPlugin, interactionPlugin],
                frLocale, arLocale,
                calenderEvents: [],
                currentEvent: {}

            }
        },
        methods: {
            handleSelect(e) {
                this.currentEvent = e.event;
                this.showModal = true;

                console.log(e.event)
            }
        },
        mounted() {
            // Do something useful with the data in the template
            this.calenderEvents = JSON.parse(this.events);
            if (this.language == 'ar') this.local = arLocale;
            else if (this.language == 'fr') this.local = frLocale;
        }
    }
</script>

<style lang='scss'>
    @import '~@fullcalendar/core/main.css';
    @import '~@fullcalendar/daygrid/main.css';

    .modal-mask {
        position: fixed;
        z-index: 9998;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, .5);
        display: table;
        transition: opacity .3s ease;
    }

    .modal-wrapper {
        display: table-cell;
        vertical-align: middle;
    }

</style>
