<template>

    <div class="card mt-3">
        <div class="card-body">
            <button @click="handleLike(type,id)"
                    v-bind:class="{'btn-outline-primary  ':!data.islikedByUser,'btn-primary':data.islikedByUser}"
                    class=" mb-3 btn  " :disabled="!isAUth">
                {{data.likes}}
                <slot name="likes"></slot>
                <span class="mx-2 fa fa-thumbs-o-up  "></span>
            </button>

            <button @click="handleFavorite()"
                    v-bind:class="{'btn-outline-danger ':!data.isfavoriedByUser,'btn-danger':data.isfavoriedByUser}"
                    class=" mb-3 btn  " :disabled="!isAUth">
                <slot v-if="data.isfavoriedByUser" name="unfavorite"></slot>
                <slot v-else name="favorite"></slot>
                <span class="mx-2 fa fa-heart-o  "></span>
            </button>

            <button class="btn btn-outline-success  mb-3  " data-toggle="collapse" data-target="#demo">
                <slot  name="share"></slot>
                <span class="mx-2 fa fa-share  "></span>

            </button>

            <div id="demo" class="collapse">

                <a onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;"
                   :href="'https://www.facebook.com/sharer/sharer.php?u='+activeUrl">
                    <span class="fa-stack fa-lg" style="color: rgb(59, 89, 152);">
                        <i class="fa fa-square fa-stack-2x"></i>
                        <i class="fa  fa-facebook fa-stack-1x " style="color: white;"></i>
                    </span>
                </a>
                <a :href="'https://twitter.com/intent/tweet?url='+activeUrl"
                   onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;">
                    <span class="fa-stack fa-lg" style="color: rgb(91, 192, 222);">
                        <i class="fa fa-square fa-stack-2x"></i>
                        <i class="fa  fa-twitter fa-stack-1x " style="color: white;"></i>
                    </span>
                </a>


            </div>
            <ul class="list-group list-group-flush">

                <li class="list-group-item" v-for="comment in comments">
                    <div class="row">
                        <div class="col-4 col-md-2 col-lg-1">
                            <img :src="url+'/uploads/'+comment.user.avatar" class="rounded-circle  img-fluid" alt=""/>
                        </div>
                        <div class="col-12 col-md-10 col-lg-11">
                            <div>

                                <div class="mic-info">
                                    <h3><b>{{ comment.user.full_name }} </b></h3>{{comment.date}}

                                </div>
                            </div>
                            <div class="comment-text">
                                {{comment.body}}
                            </div>
                            <div class="mt-3">
                                <button @click="handleLike('App\\Comment',comment.id)"
                                        v-bind:class="{'btn-outline-primary  ':!comment.is_liked,'btn-primary':comment.is_liked}"
                                        class=" mb-1 btn btn-sm  " :disabled="!isAUth">
                                    {{comment.likes.length}}
                                    <slot name="likes2"></slot>
                                    <span class="mx-2 fa fa-thumbs-o-up  "></span>
                                </button>
                                <a v-if="isAUth" class=" mb-1 btn btn-sm btn-warning" @click="comment.reply=!comment.reply"> <i
                                        class="fa fa-reply"></i>
                                    <slot name="reply"></slot>
                                </a>
                                <a v-if=" comment.user_id==isAUth" class=" mb-1 btn btn-sm btn-success text-white "
                                   @click="popUpdate(comment)"> <i class="fa fa-pencil"></i>
                                    <slot name="edit"></slot>
                                </a>
                                <a v-if=" comment.user_id==isAUth" class=" mb-1 btn btn-sm btn-danger text-white"
                                   @click="confirmDelete(comment.id)"> <i class="fa fa-trash"></i>
                                    <slot name="delete"></slot>
                                </a>
                                <div v-if="   comment.reply" class="mt-2">
                                    <div class="mb-2">
                                        <textarea class="form-control richTextBox" v-model="comment.replyText"
                                                  name="comment_body"></textarea>
                                    </div>
                                    <button class="mb-1 btn btn-sm btn-success" @click="replyComment(comment)"
                                            :disabled="!comment.replyText" type="submit">
                                        <slot name="button"></slot>
                                    </button>
                                </div>
                                <ul v-bind:class="{'pr-4 border-right':!lang ,'pl-4 border-left':lang ,}" class=" mt-2"
                                    v-if="comment.replies.length>0">

                                    <li class="my-2" v-for="reply in comment.replies">
                                        <div class="row">
                                            <div class="col-4 col-md-2 col-lg-1">
                                                <img :src="url+'/uploads/'+reply.user.avatar"
                                                     class="rounded-circle  img-fluid" alt=""/>
                                            </div>
                                            <div class="col-12 col-md-10 col-lg-11">
                                                <div>

                                                    <div class="mic-info">
                                                        <h3><b>{{ reply.user.full_name }} </b></h3>{{reply.date}}

                                                    </div>
                                                </div>
                                                <div class="comment-text">
                                                    {{reply.body}}
                                                </div>
                                                <div class="mt-3">
                                                    <button @click="handleLike('App\\Comment',reply.id)"
                                                            v-bind:class="{'btn-outline-primary  ':!reply.is_liked,'btn-primary':reply.is_liked}"
                                                            class=" mb-1 btn btn-sm  " :disabled="!isAUth">
                                                        {{reply.likes.length}}
                                                        <slot name="likes2"></slot>
                                                        <span class="mx-2 fa fa-thumbs-o-up  "></span>
                                                    </button>

                                                    <a v-if="reply.user_id==isAUth"
                                                       class=" mb-1 btn btn-sm btn-success text-white " @click="popUpdate(reply)">
                                                        <i class="fa fa-pencil"></i>
                                                        <slot name="edit"></slot>
                                                    </a>
                                                    <a v-if="reply.user_id==isAUth" class=" mb-1 btn btn-sm btn-danger text-white"
                                                       @click="confirmDelete(reply.id)"> <i class="fa fa-trash"></i>
                                                        <slot name="delete"></slot>
                                                    </a>


                                                </div>

                                            </div>

                                        </div>
                                    </li>


                                </ul>


                            </div>

                        </div>

                    </div>
                </li>


            </ul>
            <div v-if="isAUth" class="mt-5">
                <slot name="title"></slot>
                <div class="mb-2">
                    <textarea class="form-control richTextBox" v-model="comment" name="comment_body"></textarea>
                </div>
                <button class="btn  btn-success" @click="storeComment()" :disabled="!comment" type="submit">
                    <slot name="button"></slot>
                </button>

            </div>
            <div v-else class="mt-5">
                <slot name="guest"></slot>
            </div>
        </div>

        <div v-if="showModal">
            <transition name="modal">
                <div class="modal-mask">
                    <div class="modal-wrapper">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">
                                        <slot name="edit"></slot>
                                    </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true" @click="showModal = false">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <textarea class="form-control richTextBox" v-model="editable.body"
                                              name="comment_body"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-success" @click="updateComment()" :disabled="!editable.body"
                                            type="submit">
                                        <slot name="button"></slot>
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </transition>
        </div>

    </div>
</template>

<script>


    export default {


        props: ['url', 'lang', 'id', 'type', 'deleteHeaderText', 'deleteBodyText'],
        data() {
            return {

                comments: [],
                comment: '',
                isAUth: null,
                showModal: false,
                editable: {},
                reply: '',
                activeUrl: '',
                share: false,
                data: {}

            }
        },
        methods: {

            init() {
                axios.post(this.url + this.lang + '/comments', {id: this.id, type: this.type}).then((res) => {
                    this.comments = res.data.comments.map(c => {
                        c.reply = false;
                        c.replyText = '';
                        return c;
                    });
                    this.isAUth = res.data.isAUth;
                    this.data = res.data;

                })
            },
            storeComment() {

                axios.post(this.url + this.lang + '/comments/' + this.id, {
                    body: this.comment,
                    commentable_type: this.type
                }).then(() => {
                    this.init();
                    this.comment = '';

                }).catch(err => {
                    Swal.fire("error ", "error", "error");
                })

            },
            replyComment(comment) {
                let com = {...comment};
                comment.replyText = '';
                comment.reply = false;

                axios.post(this.url + this.lang + '/comments/' + this.id, com).then(() => {
                    this.init();
                    this.comment = '';

                }).catch(err => {
                    Swal.fire("error ", "error", "error");
                })

            },
            handleLike(type,id) {

                axios.post(this.url + this.lang + '/comments/likes', {
                    id: id,
                    type: type
                }).then(() => {
                    this.init();


                }).catch(err => {
                    Swal.fire("error ", "error", "error");
                })

            },
            handleFavorite() {

                axios.post(this.url + this.lang + '/comments/favorites', {
                    id: this.id,
                    type: this.type
                }).then(() => {
                    this.init();


                }).catch(err => {
                    Swal.fire("error ", "error", "error");
                })

            },

            popUpdate(com) {
                this.editable = {...com};
                this.showModal = true;
            },


            updateComment() {
                this.showModal = false;

                axios.post(this.url + this.lang + '/comments/' + this.editable.id, {
                    ...this.editable,
                    _method: 'PUT'
                }).then((res) => {
                    this.init();
                    this.editable = {};


                }).catch(err => {
                    Swal.fire("error ", "error", "error");
                })

            },

            confirmDelete(id) {
                Swal.fire({
                    title: this.deleteHeaderText,
                    text: this.deleteBodyText,
                    icon: 'warning',
                    showCloseButton: true,
                    showCancelButton: true,
                    confirmButtonText: 'Yes',
                    cancelButtonText: 'Cancel',
                }).then((value) => {
                    if (value.value) {
                        this.deleteComment(id);

                    }
                });
            },


            deleteComment(id) {
                axios.post(this.url + this.lang + '/comments/' + id, {_method: 'delete'}).then(() => {
                    this.init();
                }).catch(err => {
                    Swal.fire("error ", "error", "error");
                })


            }
        },
        mounted() {

            this.activeUrl = window.location.href;

            this.init()


        }

    }


</script>

<style scoped>

</style>
