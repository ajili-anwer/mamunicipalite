<template>
    <h4>
    <span class="badge  badge-primary" v-for="fav in data.events">
        <a  target="_blank" :href="url+lang+'/event/'+fav.slug">{{fav.title}}</a>
        <span class="badge badge-light" @click="handleFavorite(fav.pivot)"> <i class="fa fa-close"></i></span>
    </span>
        <span class="badge  badge-primary" v-for="fav in data.posts">
        <a  target="_blank" :href="url+lang+'/post/'+fav.slug" class="badge  badge-primary">{{fav.title}} </a>
            <span class="badge badge-light" @click="handleFavorite(fav.pivot)">
            <i class="fa fa-close"></i>
        </span>
        </span>
        <span class="badge  badge-primary" v-for="fav in data.ideas">
        <a  target="_blank" :href="url+lang+'/participer/idea/'+fav.id" class="badge  badge-primary">{{fav.sujet}}
           </a>
            <span class="badge badge-light" @click="handleFavorite(fav.pivot)">
            <i class="fa fa-close"></i>
        </span>
        </span>
        <span class="badge  badge-primary" v-for="fav in data.galleries">

        <a  target="_blank" :href="url+lang+'/gallery/'+fav.id" class="badge  badge-primary">{{fav.name}}
            </a><span class="badge badge-light" @click="handleFavorite(fav.pivot)">
            <i class="fa fa-close"></i>
        </span>
        </span>

    </h4>

</template>

<script>
    export default {
        name: "FavoritesComponent",
        props: ['url', 'lang', 'id', 'type', 'deleteHeaderText', 'deleteBodyText'],
        data() {
            return {

                comments: [],
                comment: '',
                isAUth: null,
                showModal: false,
                editable: {},
                reply: '',
                activeUrl: '',
                share: false,
                data: {}

            }
        },
        methods: {

            init() {
                axios.get(this.url + this.lang + '/moncompte/favoritesList').then((res) => {
                    this.data = res.data;

                })
            },

            handleFavorite(data) {
                axios.post(this.url + this.lang + '/moncompte/deleteFavorite', {...data}).then((res) => {
                    this.data = res.data;
                    this.init();

                })


            },


        },
        mounted() {

            this.activeUrl = window.location.href;

            this.init()


        }
    }
</script>

<style scoped>

</style>
