window.Vue = require('vue');
Vue.component('poll', require('./poll.vue').default);
Vue.component('poll-question', require('./poll-question.vue').default);
Vue.component('poll-creator', require('./poll-creator.vue').default);

var vm = new Vue({ el: '#app' });
