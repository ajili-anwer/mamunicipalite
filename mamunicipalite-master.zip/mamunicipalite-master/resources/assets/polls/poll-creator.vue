<template>
    <div id="vueify">
        <h1 class="page-title">
            <i class="voyager-bar-chart"></i> New Poll
        </h1>

        <div id="polls">

            <div class="container-fluid">

                <div class="panel panel-bordered">

                    <div class="panel-heading">
                        <h3 class="panel-title">Add Your New Poll Below</h3>
                    </div>

                    <div class="panel-body">

                        <div class="col-md-6" id="poll_name">
                            <div class="col-md-12 form-group">
                                <input type="text" name="poll_name" placeholder="Give this poll a name"
                                       v-model="poll.name" class="form-control">


                            </div>
                            <div class="col-md-6 form-group">

                                <input type="date" name="poll_start" placeholder="start"
                                       v-model="poll.date_start" class="form-control">


                            </div>
                            <div class="col-md-6 form-group">

                                <input type="date" name="poll_end" placeholder="end"
                                       v-model="poll.date_end" class="form-control">
                            </div>
                            <div class="col-md-6 form-group">
                                <input type="file" accept="image/jpeg" style="    font-size: 10px;padding: 10px;"
                                       @change=uploadImage class="form-control"/>
                                <button @click="resetimage" class="form-control btn btn-warning">reset image</button>

                            </div>
                            <div class="col-md-6"><img v-bind:src="preview" class="img-thumbnail"/></div>
                        </div>


                        <div class="col-md-6" id="poll_text">

							<textarea name="" v-model="poll.text" placeholder="text" class="form-control" id=""
                                      cols="30" rows="10">

							</textarea>


                        </div>

                        <div class="clearfix"></div>


                        <div class="col-md-6">
                            <draggable v-model="poll.questions">


                                <transition-group>
                                    <poll-question v-for="(question, index) in poll.questions" :question="question"
                                                   :index="index" :key="index+1"
                                                   v-on:delete-question="deleteQuestion(index)"></poll-question>
                                </transition-group>
                            </draggable>
                            <button class="btn btn-primary btn-question" @click="createNewQuestion"><i
                                    class="voyager-question"></i> Another Question +
                            </button>
                        </div>

                        <div class="col-md-6">
                            <label for="preview">Preview:</label>
                            <poll :poll="poll"></poll>
                        </div>

                    </div>
                    <div class="panel-footer">
                        <button class="btn btn-primary pull-right" id="create" @click="savePoll"
                                v-html="saveCopy"></button>
                        <div style="clear:both"></div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</template>

<style type="text/css">
    #poll_name, #poll_slug {
        padding-bottom: 30px;
        margin-bottom: 30px;
        border-bottom: 1px solid #f1f1f1;
    }


    .btn-question {
        margin-top: 20px;
        display: block;
        width: auto;
        margin: 20px auto;
    }

    .voyager-refresh {
        -webkit-animation: spin 0.6s infinite linear;
        -moz-animation: spin 0.6s infinite linear;
        animation: spin 0.6s infinite linear;
        display: inline-block;
        width: 18px;
        height: auto;
        transform-origin: 8px 9px;
        position: relative;
        top: 2px;
    }

    .btn-question i {
        position: relative;
        top: 2px;
    }
</style>

<script>
    let draggable = require('vuedraggable');
    let axios = require('axios');
    let slugify = require('slugify');


    export default  {

        props: ['url', 'edit_poll'],

        data: function () {
            return {
                newQuestionCopy: 'Create New Question',
                newQuestionLoadingCopy: '<span class="voyager-refresh"></span> Saving New Poll',
                updateQuestionCopy: 'Update Question',
                saveCopy: '',
                post_url: '',
                preview:'',
                image: {},
                poll: {
                    id: '',
                    image: '',
                    resetimage:false,
                    name: '',
                    text: '',
                    questions: []
                }
            }

        },
        methods: {

            resetimage: function () {

                this.preview = '';
                this.poll.resetimage=true;

            },

            uploadImage(e) {
                const image = e.target.files[0];
                const reader = new FileReader();
                reader.readAsDataURL(image);
                this.image = image;


                reader.onload = e => {
                    this.preview = e.target.result;
                };
            },
            newQuestion: function () {
                return {
                    id: '',
                    question: '',
                    type: '',
                    answers: [
                        {'id': '', 'answer': ''},
                        {'id': '', 'answer': ''},
                        {'id': '', 'answer': ''}
                    ]
                }
            },
            createNewQuestion: function () {
                this.poll.questions.push(this.newQuestion());
            },
            savePoll: function () {
                this.saveCopy = this.newQuestionLoadingCopy;

                let config= {
                    header : {
                        'Content-Type' : 'image/png'
                    }
                }

                var that = this;
                let formData = new FormData();
                formData.append('image', this.image);
                formData.append('poll',JSON.stringify(this.poll) );
                axios.post(this.post_url, formData,config)
                    .then(function (response) {
                        if (response.data.status == "success") {
                            toastr.success(response.data.message);
                            window.location.href = '/admin/polls';
                            that.saveCopy = that.updateQuestionCopy;
                            that.newQuestionCopy = that.updateQuestionCopy;
                            that.post_url = that.url + '/admin/polls/edit';
                            that.poll = response.data.poll;
                            history.replaceState(null, null, '/admin/polls/' + that.poll.id + '/edit');
                        } else {
                            toastr.error(response.data.message);
                            that.saveCopy = that.newQuestionCopy;
                        }

                    })
                    .catch(function (error) {
                        that.saveCopy = that.newQuestionCopy;
                        toastr.error(error.message);
                    });
            },
            deleteQuestion: function (index) {
                this.poll.questions.splice(index, 1);
            }
        },
        created: function () {
            console.log("hello")
            if (this.edit_poll) {
                this.poll = JSON.parse(this.edit_poll);
                this.newQuestionCopy = this.updateQuestionCopy;

            this.preview="/uploads/"+this.poll.image;


                this.post_url = this.url + '/admin/polls/edit';
            } else {
                this.createNewQuestion();
                this.post_url = this.url + '/admin/polls/add';
            }

            this.saveCopy = this.newQuestionCopy;
        },
        components: {
            draggable: draggable,
        },
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
