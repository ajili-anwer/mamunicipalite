
function openNav() {

   $("#mySidenav").css('width','250px') ;

   $("#main").css('margin-left','250px');

}


function closeNav() {


    $("#mySidenav").css('width','0') ;

    $("#main").css('margin-left','0');


}


