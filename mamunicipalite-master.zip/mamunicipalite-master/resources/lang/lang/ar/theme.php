<?php

return [
    'footer_copyright'  => 'صنعت بـ <i class="voyager-heart"></i> بواسطة',
    'footer_copyright2' => 'مصنوعة باستخدام الكثير من القهوة والشاي بالنعناع',
];
