function tinymce_init_callback(editor) {
    // editor.remove();
    // editor = null;
    tinymce.init({
        menubar: !1,
        selector: ".richTextBox",
        min_height: 200,
        skin_url: $('meta[name="assets-path"]').attr('content') + '?path=js/skins/voyager',
        resize: "vertical",
        plugins: "link, image, code, youtube, giphy, table, textcolor, lists  preview searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor  insertdatetime advlist lists wordcount imagetools textpattern  code textcolor",
        extended_valid_elements: "input[id|name|value|type|class|style|required|placeholder|autocomplete|onclick]",

        file_browser_callback: function (e, t, n, i) {
            "image" == n && $("#upload_file").trigger("click")
        },

        toolbar: 'formatselect | bold italic strikethrough | forecolor backcolor | link image media | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent | ltr rtl | removeformat | giphy | code',
        convert_urls: false,
        image_caption: true,
        image_title: true,

        valid_elements: 'div[*],p[*],span[*],ul[*],li[*],ol[*],hr,br,img[*],i[*],em,table[*],tr[*],td[*],th[*],sup[*],sub[*],strong[*],b,h1[*],h2[*],h3[*],h4[*],h5[*],h6[*],small[*],a[*], svg,path',
        valid_children: '+li[span|p|div]',
        content_style: '.mce-annotation { background: #fff0b7; } .tc-active-annotation {background: #ffe168; color: black; }',

        external_plugins: {
            'print': '/vendor/tcg/voyager/assets/js/plugins/print/plugin.min.js',
            'preview': '/vendor/tcg/voyager/assets/js/plugins/preview/plugin.min.js',
            'searchreplace': '/vendor/tcg/voyager/assets/js/plugins/searchreplace/plugin.min.js',
            'directionality': '/vendor/tcg/voyager/assets/js/plugins/directionality/plugin.min.js',
            'visualchars': '/vendor/tcg/voyager/assets/js/plugins/visualchars/plugin.min.js',
            'visualblocks': '/vendor/tcg/voyager/assets/js/plugins/visualblocks/plugin.min.js',
            'autolink': '/vendor/tcg/voyager/assets/js/plugins/autolink/plugin.min.js',
            'fullscreen': '/vendor/tcg/voyager/assets/js/plugins/fullscreen/plugin.min.js',
            'media': '/vendor/tcg/voyager/assets/js/plugins/media/plugin.min.js',
            'template': '/vendor/tcg/voyager/assets/js/plugins/template/plugin.min.js',
            'codesample': '/vendor/tcg/voyager/assets/js/plugins/codesample/plugin.min.js',
            'code': '/vendor/tcg/voyager/assets/js/plugins/code/plugin.js',
            'charmap': '/vendor/tcg/voyager/assets/js/plugins/charmap/plugin.min.js',
            'pagebreak': '/vendor/tcg/voyager/assets/js/plugins/pagebreak/plugin.min.js',
            'hr': '/vendor/tcg/voyager/assets/js/plugins/hr/plugin.min.js',
            'anchor': '/vendor/tcg/voyager/assets/js/plugins/anchor/plugin.min.js',
            'nonbreaking': '/vendor/tcg/voyager/assets/js/plugins/nonbreaking/plugin.min.js',
            'insertdatetime': '/vendor/tcg/voyager/assets/js/plugins/insertdatetime/plugin.min.js',
            'wordcount': '/vendor/tcg/voyager/assets/js/plugins/wordcount/plugin.min.js',
            'imagetools': '/vendor/tcg/voyager/assets/js/plugins/imagetools/plugin.min.js',
            'textpattern': '/vendor/tcg/voyager/assets/js/plugins/textpattern/plugin.min.js',
            'advlist': '/vendor/tcg/voyager/assets/js/plugins/advlist/plugin.min.js',
            'youtube': '/vendor/tcg/voyager/assets/js/plugins/youtube/plugin.js',
            'giphy': '/vendor/tcg/voyager/assets/js/plugins/giphy/plugin.js',
        }

    })

}
